# Independent review: authenticated legacy tunnel verification

Reviewed immutable commit `b88f8508f68a3da582fabd0d49bdcac5bae2b77f` against stable base `2d4933a77d300614b7de2e6dc328d77f7947283d`, using the full #214 contract. Review was read-only; no tests/builds or provider endpoints were run by this reviewer. Writer reports focused 59/59 and lint/typecheck passed. The portable suite's only two failures were ENOSPC and passed in isolation; this review does not independently verify that run.

## Findings

No blocker found in the requested legacy `action-server start --expose` path. With an API key configured, tunnel readiness now requires an exact HTTPS origin, rejects redirects, checks public `/config` for `auth_enabled` and the same in-memory `mtime_uuid` before and after MCP initialization, confirms an unauthenticated initialize gets 401/403, and performs a real SDK authenticated `initialize`. A single 8-second monotonic deadline bounds the network exchange. The public URL is logged only after this succeeds; no Action call is made. Failure logs only the exception class and stops the manager, without logging the key or URL.

The MCP live app receives the same DNS-rebinding `TransportSecuritySettings` object that is temporarily extended with the exact validated tunnel host and HTTPS origin. Entries are reference counted; the release callback is idempotent, preserves pre-existing entries, is registered with the owning manager, and runs both on failed verification and manager stop (including stop failure via `finally`). Tests cover MCP host scoping, unauthorized rejection, authenticated initialization, reference counts, pre-existing entries, and cleanup.

No expanded lifecycle claim is warranted: this change does not establish the separate persisted `action-server expose start/status` readiness path. Standalone lifecycle is still starting/unverified; no live provider, public TLS edge, or native Windows/macOS acceptance was exercised. No action call is part of the probe.

## Documentation improvement

- **Canonical file changed or proposed:** `docs/skills/repository-operations.md` (changed in the reviewed commit); user-facing scope clarification in `action_server/docs/guides/05-exposing.md`.
- **Durable learning captured:** Authenticated legacy expose must verify public Runtime identity and MCP auth before logging the URL; the MCP SDK's live app must receive the same settings object used for the temporary exact tunnel host/origin allowance, which is reference counted and released on verification failure or manager stop.
- **Evidence:** Committed code and tests at `b88f8508`; writer-reported focused 59/59 and lint/typecheck. No live provider/TLS or native platform result is asserted.
- **Stale or ambiguous guidance removed:** None; scope and limitations are additive and explicitly distinguish the legacy shortcut from persisted lifecycle status.
- **Remaining uncertainty:** Separate persisted lifecycle stays starting/unverified. Public provider/TLS behavior and native Windows/macOS CI remain unverified. Full suite had two reported transient ENOSPC failures that passed alone, not independently reproduced here.
