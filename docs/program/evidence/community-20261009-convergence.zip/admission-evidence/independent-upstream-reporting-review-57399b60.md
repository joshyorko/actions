# Independent successor review: upstream reporting guidance at `57399b6`

## Verdict

**Accepted for the reviewed documentation scope.** Reviewed exact commit `57399b60496b98fea020f26e576d47bcb0d440bf` against `85e7f1ef177a68abe6374061ad049d3cf88ecf66` on `docs/upstream-reporting-policy-20261009`. The successor adds policy refinements in the existing index-linked guide, root instructions, and repository-local skill; it does not add implementation scope. `git diff --check` passed. No external issue graph search or mutation, merge, or publication was performed.

## Requested refinements

- **Integration and external-service classification:** The guide now requires isolating caller, provider, network, and published contract, and says an integration failure alone does not identify an upstream owner. A defect requires evidence that upstream violates a documented supported contract.
- **Unsupported version and missing capability:** Unsupported-version breakage is classified as compatibility/support, with a defect candidate only when a supported version violates its compatibility promise. Missing capability without a broken contract is a feature request/product decision, kept distinct from bug reports.
- **Confirmed defect reporting and deduplication:** For a confirmed new defect within authorized target scope, the guide calls for one focused issue after deduplication and a downstream link; equivalent existing reports are updated or linked rather than duplicated. Existing open+closed issues/PRs search requirement remains.
- **Mitigation authority:** A local mitigation already authorized by the active task needs no separate approval, but must remain narrow, tested, owned, linked to the upstream issue, and have a concrete removal condition. Out-of-scope source changes require authority.
- **Dispatch and receipts:** Root AGENTS now directs every assignment to state target-specific issue-only authority or draft-only status and to return an explicit upstream disposition. The repository skill and AGENTS require `Upstream disposition: none` when no investigation was needed, or the factual disposition otherwise.
- **Dated campaign scope:** The guide states the 2026-10-09 campaign's issue-only authority for confirmed defects in explicitly in-scope maintained `joshyorko` repositories, including `joshyorko/rcc`, conditional on account permissions and repository rules. It expressly denies any other mutation authority and says the authorization is not standing for later tasks; each active task must verify authority. The root assignment instruction further requires the actual authorized target to be stated.

The prior review's requirements remain intact: confidential/security findings use private target procedures; Bluefin is process precedent only; it imports no hive labels, design-response format, parent-issue convention, or protocol prohibition; and the guide does not grant credentials or blanket owner-repository mutation authority.

## Upstream disposition

- Candidate repository, owner, and consumed version/revision: No concrete upstream defect candidate was investigated in this successor documentation review. The guide retains the immutable RCC source references and the prior review verified the local consumer pin as RCC `v18.19.3`.
- Classification and evidence: No defect classification; review was limited to reporting policy text and its authority boundaries.
- Deduplication searched (issues and pull requests): Not performed; there was no defect candidate to deduplicate.
- Disposition: No confirmed upstream defect; no issue filed or updated.
- Maintainer decision/follow-up trigger: None. For a future candidate, verify exact task authority and target before reporting.
- Downstream issue, gate, or consumer affected: Documentation policy only.
- Temporary mitigation owner and removal condition: None.
- Remaining uncertainty: The campaign's exact authorized target set is intentionally constrained by “explicitly in-scope” and must be stated in each active task; this review did not independently enumerate that set or query upstream issue state.

## Documentation improvement receipt

- **Canonical file changed or proposed:** Existing `docs/skills/upstream-reporting.md`, with dispatch and receipt requirements added to `AGENTS.md` and `.agents/skills/actions-repository/SKILL.md`. No further delta proposed.
- **Durable learning captured:** Integration failures need contract/owner isolation; unsupported versions and feature gaps are not defects by default; authorized fixes need not trigger redundant approval; every assignment must carry scope and every task reports an upstream disposition; campaign authority is dated and target-limited.
- **Evidence:** Exact successor diff and clean `git diff --check`; prior review verified the local RCC consumer version and guide citations.
- **Stale or ambiguous guidance removed:** Replaced the earlier narrowly conditional mitigation wording with a clear active-task-authority rule; broadened the completion receipt from defect-investigation tasks to all normal task completions while retaining the detailed receipt for investigations.
- **Remaining uncertainty:** Exact campaign target list is not enumerated in the policy text; the dispatch rule mitigates this by requiring each task to state its authorized target. No source defect investigation or upstream issue-state audit was in scope.
