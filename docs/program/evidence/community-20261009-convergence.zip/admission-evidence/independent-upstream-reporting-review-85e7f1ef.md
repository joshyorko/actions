# Independent review: upstream reporting guidance at `85e7f1ef`

## Verdict

**Accepted for the reviewed documentation scope.** This is a read-only review of commit `85e7f1ef177a68abe6374061ad049d3cf88ecf66` on `docs/upstream-reporting-policy-20261009`. The worktree was clean, the commit changes only `.agents/skills/actions-repository/SKILL.md`, `AGENTS.md`, `docs/skills/README.md`, and the new `docs/skills/upstream-reporting.md`, and `git diff --check 85e7f1ef^ 85e7f1ef` passed. No implementation, external report, issue mutation, merge, or publication was performed.

## Scope checks

- **Ownership and consumed version:** The guide requires checking the true source owner, remote/fork, and exact consumed version or immutable revision before classification. It identifies `joshyorko/rcc` as the maintained RCC release source and `admariner/rcc` as historical lineage, with immutable source links and an explicit instruction to reverify repository facts at report time. The local RCC pin is corroborated by `action_server/src/actions/server/_rcc_runtime_adapter.py` (`RCC_VERSION = "v18.19.3"`, line 23) and the root `AGENTS.md` toolchain instructions.
- **Evidence and deduplication:** It calls for a minimal reproduction, consumed version, expected/observed behavior, redacted output, immutable source anchors, and separation of facts from hypotheses. It explicitly requires searching open and closed issues and pull requests on the canonical owner and relevant fork, reusing an existing report where evidence matches, and commenting only for material updates.
- **Issue-only authority:** The policy says the guide, role, access, or existing issue grants no authority. External issue creation requires explicit target-specific authorization for a confirmed new defect; that authority excludes code, branches, PRs, labels, assignment, settings, merge, releases, and publication. It directs out-of-scope/third-party reports to remain drafts pending authority.
- **Security handling:** Vulnerability, credential, private-data, and exploitable findings are routed to the target repository's private security procedure. The guide prohibits putting confidential details in the public report or the general receipt.
- **Mitigation lifecycle:** Any separately authorized downstream mitigation must be narrow, tested, linked to the upstream report, owned, and have a concrete removal condition. It explicitly rejects silently retaining a fallback after upstream resolution.
- **Dispatch and completion receipt:** The guide requires follow-up only on evidence/maintainer/release/downstream-gate triggers, forbids timer-based status comments, and defines an explicit disposition receipt even when no issue is filed.
- **Bluefin adaptation:** Bluefin is framed as a process precedent for evidence and follow-up only. Hive labels, design responses, parent-issue conventions, and protocol restrictions are expressly not imported.
- **Discoverability and boundaries:** Root `AGENTS.md` links the new guide; the canonical guide index lists it; the repository-local Actions skill references it and says reading it grants no external mutation authority. No credential grant or blanket `joshyorko` mutation authority is present.

## Upstream disposition

- Candidate repository, owner, and consumed version/revision: No concrete upstream defect candidate was investigated in this documentation-policy review. The guide's RCC ownership/version statements are linked to immutable RCC revision `47a60ea78c5d97c892177f5649a1c950399faa6a`; the local Actions consumer pin is RCC `v18.19.3`.
- Classification and evidence: No defect classification was made; this review assessed reporting policy and verified its local consumer pin and immutable references.
- Deduplication searched (issues and pull requests): Not performed because no defect candidate was under investigation.
- Disposition: No confirmed upstream defect; no issue was filed or updated.
- Maintainer decision/follow-up trigger: None. For an actual candidate, reverify ownership and consumed revision, then follow the guide's evidence/deduplication/authority procedure.
- Downstream issue, gate, or consumer affected: Documentation policy only; the RCC consumer pin is cited as an example of required version verification.
- Temporary mitigation owner and removal condition: None.
- Remaining uncertainty: Current upstream ownership and issue status were not independently queried during this docs-only policy review; the guide correctly makes revalidation at report time mandatory.

## Documentation improvement receipt

- **Canonical file changed or proposed:** `docs/skills/upstream-reporting.md`, indexed in `docs/skills/README.md`; root `AGENTS.md` and `.agents/skills/actions-repository/SKILL.md` point contributors to it. No further delta proposed.
- **Durable learning captured:** A repeatable authority-bounded upstream defect workflow covering ownership/version proof, reproducibility, open/closed deduplication, private security handling, narrow mitigations with removal criteria, maintainer follow-up, and a no-report disposition receipt; Bluefin practices are adapted without importing its governance.
- **Evidence:** Reviewed exact commit diff and current local RCC pin; immutable RCC links are included in the new guide. `git diff --check` passed.
- **Stale or ambiguous guidance removed:** No contradictory upstream reporting guide or competing local authority grant was found in the reviewed files. The change explicitly distinguishes policy from permission and historical lineage from current RCC release ownership.
- **Remaining uncertainty:** The immutable linked upstream facts are intentionally not timeless; current ownership and target issue/security guidance must be checked again before any real report.
