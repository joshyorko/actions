# Sol pinned RCC trust policy review

Architectural decision: reject automatic providerless fallback. The configured HTTP trust-carrier warm path is BLOCKED on an explicit supported offline trust contract. A separate concrete Actions P1 requires repair: acquisition supplies the configured provider, but new metadata/worker `env exec` commands drop that carrier. Root approved a narrow RCC descriptor/provider-binding repair, with independent source and real-negative review before admission. PR247 bounded retirement acceptance remains intact. No tests, signals or implementation edits were performed in this lane.

## Exact evidence

Actual Actions acceptance source is `ef9195daa9ca8c1d3fbc7c8fc998e39602595a21`. Receipt `acceptance-ef9195da.json` SHA-256 is `905d928cd708c7435d35d138acdf774c1536227763a0a0422e9cd9753e75eea6`. Pinned RCC binary is v18.19.3, SHA-256 `7e588c01751ca2ae15ba13ef67f2f4b7567697a5a8389737059a73936f509428`. GitHub tag v18.19.3 resolves to commit `4148c2b71705c9d2baf0e88b48d08a79cb7bda0f`. Versioned source/doc excerpts were downloaded for read-only inspection into `worker-exit-evidence/sol-trust-source`; no source checkout or new environment was created.

The phase-isolated comparison records lifecycle inspection with no requests. Provider-backed acquire requests `/<exact digest>/provenance.json`, receives 503 and fails with `artifact trust attachment verification failed`. The same home/digest without provider acquires successfully with exact identity and verification.valid=true, with no probe requests. Warm Runtime separately repeats the configured provenance request and acquire failure. Thus request attribution is now established, unlike the earlier cumulative-count ae6db6b8 probe. Warm execution and zero-network configured-trust acceptance remain FAIL.

## What pinned RCC actually enforces

Immutable references:

- `https://github.com/joshyorko/rcc/blob/4148c2b71705c9d2baf0e88b48d08a79cb7bda0f/docs/environment-artifact-trust.md`
- Same commit, `cmd/environmentAcquire.go`, `cmd/environmentExec.go`, `cmd/environmentTrustPolicy.go`.
- Same commit, `environmentlifecycle/materialize.go`, `environmentlifecycle/trust.go`, `environmentlifecycle/lease.go`.
- Same commit, `artifacttrust/carrier.go`, `artifacttrust/trust.go`, `settings/provider.go`, `cmd/provider.go`.

The trust guide says new leases re-fetch/re-evaluate their configured carrier and record the decision. Acquire and exec support `--provider`, explicit `--trust-carrier`, `--trust-carrier-type`, `--trust-roots`, and mutually exclusive strict-remote/permissive-local policy flags. The default policy is strict-remote with fail-closed revocation freshness. Explicit permissive-local permits unsigned local artifacts and disables the fail-closed freshness flag; it does not suppress a configured carrier read/decoding failure.

The source is stronger and more precise than the generic CLI help:

- optionalEnvironmentTrustCarrier with no explicit carrier but a provider reference chooses HTTPCarrier. `HTTPCarrier.Read` recognizes 404 as an absent optional attachment; 503 is an error. LoadAttachments propagates non-absence errors. Acquisition persists trust failure and does not return a successful materialization/decision.
- With neither provider nor explicit trust carrier, that selection function returns nil. trustRequestFor with a nil carrier returns an attachment-free verification request. No implicit local filesystem trust carrier is added by defaultEnvironmentCommandDependencies/NewAcquirer.
- Consequently the provider-free permissive-local result is not proof that RCC revalidated the provider's cached provenance/SBOM/signatures/revocations. The successful verification JSON in the actual receipt lacks provenanceDigest/SBOMDigest. The same manifest digest can receive a different trust decision because detached attestations do not participate in Artifact identity.
- Local manifest/content reuse still checks compatibility and trust before warmMaterialization. Supplying the provider preserves the HTTP trust input even when no content download is needed. Content readiness and configured trust availability are separate conditions.
- env exec performs its own acquire with its selected trust inputs, binds that context to Materialization, and lease creation calls refreshMaterializationTrust again before producing the process-owned lease. Correct continuity requires the same selected carrier/policy at this boundary.

Therefore dropping the provider to make the warm test pass changes the trust input. Under root's explicit configured-trust preservation instruction, it is a bypass, not a legitimate cache optimization. This current failure matches the pinned carrier contract; it is not evidence that RCC should ignore 503 or skip revocation/attestation checks. Treat zero-network warm under a required HTTP carrier as a contract/capability blocker. A deployment may explicitly preselect a supported filesystem/archive carrier under its intended trust roots/freshness policy, but that is a separate authorized policy and must not be chosen reactively after carrier failure. Do not implement an Actions-owned authoritative attachment cache.

## Concrete Actions P1 and minimum repair

At the diagnostic checkpoint, `_action_package_handler.bootstrap_environment` supplies current provider to prepare_runtime. acquire_artifact passes it to RCC. Cache identity includes environment path/fingerprint/provider. The frozen RccRuntimeDescriptor records Artifact/source/environment identities but no carrier/provider binding. Every build_exec_command emits `env exec --artifact DIGEST --permissive-local` without provider/trust options. Both metadata/discovery helpers and TCP/stdio pool workers use that shared builder.

A provider-validated cold acquisition therefore precedes a separate carrier-free acquisition/new lease. A carrier becoming unavailable, malformed or changing relevant trust evidence between these boundaries does not constrain the old exec command. The command can execute under attachment-free permissive-local verification. This is a current source-level trust continuity defect, not merely a future generic adapter concern.

Approved minimum design, RCC only:

1. Capture the exact credential-free selected provider reference in the RCC-namespaced descriptor after successful preparation. Preserve it in initial/warm/rebuild/source-reuse/cache-copy branches. It is operational policy input, never portable Artifact identity or a generic Run/Package field.
2. Append that descriptor's exact `--provider` argument in the single shared build_exec_command. All metadata, schema and pool spawn callers then carry the same context into supported RCC acquisition/lease checks. Retain current explicit permissive-local mode consistently; do not introduce a generic trust API or expose unsupported policy modes in this repair.
3. Distinguish an explicit provider-free descriptor from a legacy descriptor whose binding is unknown. Reprepare an unknown legacy descriptor under explicit current deployment inputs before use, or reject direct exec with a clear bounded error. An absent field cannot silently mean trusted local execution under a configured provider.
4. Preserve cache partitioning by selected provider. An admitted old generation executes its captured reference; a changed current environment/config must not silently redirect it. No redacted URL is substituted for the reference.
5. Reject credentials, query/fragment and controls before RCC calls or descriptor/cache persistence. Reject malformed URL forms rather than treating them as profile names. Errors must not echo a secret reference through exception text or a chained parser exception.

Pinned provider reference spelling is literal lowercase http:// or https:// URL, reserved local, or named profile `^[a-z0-9][a-z0-9._-]{0,62}$` under cmd/provider.go/settings/provider.go. Profiles allow an authorization environment-variable name rather than its value. A sensitive path-based endpoint needs explicit operator/profile handling; do not invent token heuristics or redact a path into a different provider identity. This review does not claim every profile's detached trust carrier behavior is fully accepted.

## Required meaningful negative

Owner D should use a materialized exact artifact and selected real carrier that successfully verifies cold acquire. Then make that same carrier return 503 or malformed provenance before executing a command through Actions' repaired shared builder. The command writes a unique child side-effect marker if it starts.

Require the exec to fail before child start, no marker, no successful wrapper/lease result, and the expected same-origin trust attachment request/failure. Preserve the initial immutable Actions execution receipt. RCC's latest verification receipt may legitimately change to failure with append-only history, so do not require the mutable latest RCC verification record to remain byte-identical. A successful carrier-free control can demonstrate why the old dropped-provider command was wrong, but must remain a diagnostic control, never an accepted fallback.

Also cover exact round-trip/copy binding, explicit local versus unknown legacy, reprepare of old descriptors, source/cache branches, provider change generation pinning, and unsafe URL rejection before any runner call. These are bounded regression responsibilities for D; this reviewer does not duplicate them or run heavy proof.

## Initial design/source review status

D's proposed boundary is approved by root and accepted in this read-only design review. Initial mutable code on `repair/rcc-trust-context-20261009`, based on `2eaac1c1fe5c53320d647a35dd137f8fd9411f3b`, implements descriptor binding and shared exec propagation.

Validation finding sent to D before admission: the first implementation checks secret URL parts only when both scheme and netloc exist. It permits schemeless userinfo, malformed scheme URLs with query data, and unsafe pseudo-profile references to enter a descriptor. It also chains urlsplit ValueError, whose text may contain a secret netloc. Reject parsed userinfo/query/fragment independent of scheme, constrain supported spelling, and suppress parser cause details. Source and real-negative acceptance are pending an immutable repaired checkpoint.

## Documentation improvement receipt

- Canonical file proposed: docs/skills/repository-operations.md, after the existing provider-backed trust-carrier failure paragraph added by 52f8fd19.
- Exact durable text proposed now: "In pinned RCC v18.19.3, omitting both provider and explicit trust carrier creates an attachment-free trust request; permissive-local verification.valid does not establish equivalence to a configured HTTP carrier decision. A configured carrier read failure remains fail-closed even when content is locally ready. RCC re-evaluates the selected trust context at acquisition and new-lease boundaries. Actions must preserve that context across metadata and worker exec; a legacy descriptor with unknown binding requires explicit re-preparation, and automatic providerless fallback is not an accepted recovery policy."
- Durable learning captured: detached trust is independent of Artifact digest/content readiness, and descriptor/acquire-to-lease carrier continuity is required.
- Evidence: immutable pinned source references above and phase-isolated ef9195da receipt with exact hash. Statement of required Actions continuity is an invariant proposal until the repair is verified; it must not be presented as already implemented at 2eaac1c1.
- Stale or ambiguous guidance removed: CLI help's implied automatic local filesystem carrier cannot justify fallback; generic valid verification wording must identify the selected trust inputs.
- Remaining uncertainty: D's immutable credential-validation repair and real negative, final configured/hosted gates, explicit offline carrier policy/freshness support, profile carrier behavior and full #134 acceptance. Root records integration/disposition of this receipt.

## Immutable source review fb220383

Source verdict: ACCEPT the approved narrow P1 repair at exact SHA `fb220383e4147d1910e9fb7b47ede9928908b9b5`, observed clean. Full delta from diagnostic base `2eaac1c1fe5c53320d647a35dd137f8fd9411f3b` has SHA-256 `1b941f6494e0e80cbaba11b40633c29df75c6465059da9ac2d74d7d3e8290611`. Actual negative execution receipt is pending; this is source approval to proceed with the root-authorized single proof, not final admission.

The initial validation finding is resolved. The validator rejects parsed userinfo/query/fragment independent of scheme, controls/whitespace, malformed HTTP URL or port, and profile names outside the pinned grammar. It preserves literal accepted references without redaction or normalization and suppresses parser ValueError causes that might expose input. URL path confidentiality remains the operator's policy responsibility; this syntax check does not prove arbitrary URL paths contain no secrets.

Every descriptor creation/copy branch in prepare_runtime captures provider_reference. Existing cache keys remain provider-partitioned. Legacy JSON lacking provider_reference gets provider_context_bound=false, and the shared builder rejects direct exec until reprepare; explicit serialized None remains distinct local policy. The shared builder appends the captured --provider before the child command separator, so both metadata/discovery helpers and TCP/stdio workers use the supported RCC carrier context. No providerless recovery branch was added. No generic adapter/trust API was introduced.

The actual-negative harness uses the descriptor persisted by the first real successful Action, verifies it matches the replaced provider's exact origin, and invokes the shared builder for a Python child with an absolute marker side effect. It requires nonzero exit, the exact Artifact's provenance 503 request, no marker, no successful child receipt and byte-preserved initial execution receipt. Probe counts are reset by phase. Warm Runtime failure remains overall FAIL and a separate blocked acceptance cell; focused tests passing this known negative do not claim #134 warm acceptance.

Writer reports exact-source focused 87 passed/2 skipped, Ruff check/format check PASS and diff check PASS. These are writer gates, not independent reviewer execution. The real gate was skipped in the focused suite and must be proved separately. D and root notified that source has no blocker and the single authorized proof may proceed.

Additional canonical text proposed from source facts, supported now:

> The RCC-namespaced runtime descriptor captures the exact validated provider reference separately from Artifact identity. Metadata and worker exec use that captured reference rather than a mutable later provider setting. Legacy descriptors without a binding are unknown, not explicitly local; direct exec rejects them until preparation binds the current deployment input. Provider reference validation rejects userinfo, query/fragment, control data and unsupported syntax before RCC calls or persistence, without substituting a redacted provider identity.

Do not append a real fail-closed child-execution claim until the exact-SHA negative receipt is reviewed. Root must integrate the canonical proposal or record rejection under AGENTS.md. Earlier BLOCKED zero-network configured-HTTP-trust policy decision and full #134 limits remain unchanged.

Upstream reporting disposition under the user's new mandatory policy:

- RCC upstream finding: none. HTTP-carrier 503 failure is expected pinned fail-closed behavior, not a demonstrated RCC defect.
- Actions finding: local acquire-to-exec trust-context P1, handled in the authorized repair branch; exact source review accepted, real-negative admission still pending.
- External publication: none. No upstream issue, PR, comment, label, assignment or code change was created by this lane. No third-party reporting authority is needed for an action that was not taken.
- Issue/disclosure link: none. No speculative RCC issue or public sensitive finding was filed. Any later distinct RCC feature request or defect needs maintained-owner/current-source/dedup evidence and the user's required reporting procedure.


## First real attempt and diagnostic successor

The first actual attempt at `fb220383e4147d1910e9fb7b47ede9928908b9b5` failed in initial cold publish before successful acquisition/Action and before the selected-carrier negative. Preserved `acceptance-fb220383.log` has SHA-256 `828543e70f3918ad413fc52a0c052ede2aeb7e26c15f1a94cf2cabdb1f82a640`. Its final exception only says `RCC publish failed: [rcc] exit status will be: 1!`, with command_exit_code=1. That evidence cannot establish the publish cause or test acquire-to-exec continuity. Negative verdict for that attempt: NOT_RUN, not PASS.

Source-only diagnostic successor `2c7ec2ded7d25fc406598dc2c0675eaae55cd611` is ACCEPTED, observed clean. Exact delta from fb220383 has SHA-256 `32d0fa0baf160236ec806e53672352d327d7ce09a79227d149f9834d033a7544`. It changes only failed-command detail selection and its unit regression: skip generic trailing RCC exit/banner lines, retain the last remaining stderr (or stdout if stderr empty) line, cap at 400 characters, otherwise report command failed. It adds no policy fallback and leaves binding/legacy rules intact. Retained RCC text is diagnostic output, not a general credential sanitization guarantee. D reports focused adapter 57 passed/1 skipped and Ruff check/format PASS; no reviewer gates were run. Root and D notified no source blocker to the root-authorized single retry. Actual proof remains pending.

Additional exact canonical delta proposed in docs/skills/repository-operations.md under RCC failure evidence: "An acceptance attempt that stops during cold publish has not exercised acquisition, worker execution or an acquire-to-exec trust negative. Preserve the failed attempt and its phase. A generic trailing RCC exit-status line is not a root cause: obtain the bounded meaningful RCC error before classifying the failure or retrying. Source/unit approval and skipped real-RCC tests do not establish a live trust-continuity PASS."

Evidence: preserved hashed fb220383 log and immutable 2c7ec2de diagnostic diff. This removes ambiguity between a setup failure and the known configured-carrier warm rejection; it does not speculate about upstream cause. Upstream finding/disposition/link remains none.


## Authorized retry outcome at 2c7ec2de

Live admission verdict: BLOCKED, requested trust-negative NOT_REACHED. Preserved `acceptance-2c7ec2de.log` SHA-256 `83b406b775c782492ea0566e1ee7b52fc1794902e18ea698e109067d075e4b4a` records initial publish failure: object `sha256:e0ba46903bea70ee8260fa66083f12758d132a72df8e1861e93bbc357a16994a` upload received artifact-provider HTTP 422 Unprocessable Entity. Command exit code is 1. The initial successful Action/acquisition precondition was not established, and no JSON acceptance receipt was written. This is distinct from the already understood configured-carrier provenance 503 rejection. Source ACCEPT remains valid but is not live acceptance.

D reports owned provider cleanup and no live matching process in a post-run scan; that is an observation, not exhaustive descendant reaping. Reviewer ran no tests, processes, retries or signals. The minimum further investigation is the provider's exact 422 rejection body/reason and the configured publish contract; HTTP status alone does not assign an upstream defect. No providerless fallback is authorized.

The first version of `provider-trust-negative-preflight-2c7ec2de.json` (reported hash `b452912cf9c874372568ae27c1f4dbe113e02e315be4e843e2d5e1a2a7952a48`) incorrectly associates an interpreter/missing-requests preflight cause with the fb220383 publish-failure log. This reviewer found no requests/ModuleNotFoundError in that cited log and asked D to correct or split the evidence. Do not rely on that first-attempt cause until corrected; the second-attempt 422 and NOT_REACHED match their cited log. Root informed of source acceptance, live block and receipt correction.

Documentation improvement status remains exact proposals above awaiting root integration/disposition. Upstream finding: none established; disposition: local Actions P1 source repair accepted, live proof blocked by cold-publish precondition; issue/disclosure link: none.


Receipt correction independently read and accepted: `provider-trust-negative-preflight-2c7ec2de-correction.json` SHA-256 `9dcb44df322b8e8e85e7c2366f07c9154d515d4daace714590c348a0ef092684` supersedes the incorrect mapping while preserving the original. It explicitly separates the writer-reported, non-durably-logged shell-Python missing-requests attempt from the two hashed publish-failure attempts. The corrected receipt honestly marks the first tool-output observation without durable log, fb220383 underlying cause unknown, and 2c7ec2de HTTP 422. No acceptance receipt, trust-negative NOT_REACHED, and cleanup limits are retained. No remaining receipt blocker; live proof remains BLOCKED.


## Live narrow P1 proof at f4e03108

Independent verdict: ACCEPT the bounded provider-context continuity repair and actual selected-carrier negative at clean source `f4e031080749fd6a120a781f72c3f44d4b5832b8`. Exact receipt `acceptance-f4e03108.json` SHA-256 `38e01df3994631c25ea8714720cd2aab8c93578830965da0f9488ce7c639f58c`; complete log SHA-256 `472d8f4ecb8ff8bc1f568f1bcd33520a6b4e92bbca6ffc89ad858aa1da97b704`. Both independently hashed and read. Since source-accepted2c7ec2de, f4e changes only canonical documentation, with provider-binding and shared-builder code unchanged.

The proof now establishes its precondition: actual publish/acquire succeeded, unauthenticated HTTP403, authenticated Action200, persisted SQLite passed, initial RCC receipt completed with exitCode0, leaseId present and verification.valid=true. The same Artifact digest is `sha256:faa7f31655d99ff9bfa3e790c5f2b5a6ccdf9776d66fb4aee9a511a4112af79f`. Initial wrapper/runtime process exit is0; provider owner is recorded reaped. Candidate wheels are Core1.0.2 and Helper1.0.2, so this does not establish current Helper1.0.3 release acceptance.

The actual negative uses the persisted RCC descriptor, requires provider_reference equal the retired provider's exact origin, and runs the shared Actions exec builder. Its captured provider argument matches; that exact origin returns503 for the exact Artifact provenance GET. Wrapper exec returns1, unique child marker is absent, no successful child receipt exists, and the frozen initial receipt is byte-preserved. The source harness resets event counts around this operation, and later acquire/Runtime failures do not supply its negative events. This now proves the bounded actual acquire-to-exec carrier continuity requirement. No providerless fallback is admitted. The separate provider-free diagnostic is still just a policy-changing control.

The receipt correctly retains overall acceptance_status FAIL: locally ready Artifact lifecycle alone does not satisfy configured HTTP trust. Offline configured acquire and warm Runtime separately request provenance, receive503 and fail; warm Action, verification and wrapper success remain FAIL, and zero_requests_during_warm_runtime is FAIL. The narrow P1 is accepted independently; zero-network configured warm, full#134, exhaustive ownership/reap, all platforms and release/hosted gates are not waived. Cleanup cells retain their existing owned-process scope, not proof for arbitrary orphan descendants. Capacity recovery before this attempt does not prove the original422 storage cause; that specific historical cause remains unknown.

Canonical reconciliation required: f4e guide contains the correct provider-binding/legacy policy, but still says the same-carrier negative remains unverified. D notified to supersede that clause with these observed exact-SHA facts while retaining historical422 NOT_REACHED and overall warmFAIL. Exact text proposed: "At source f4e031080749fd6a120a781f72c3f44d4b5832b8, the real selected-carrier negative passed: after a successful initial Action, the same persisted provider returned503 for the Artifact provenance request; exec returned nonzero before the child marker, produced no successful child receipt and preserved the initial receipt. This accepts the bounded acquire-to-exec provider continuity repair. The whole acceptance receipt remains FAIL because configured-provider warm acquisition/execution cannot proceed when that carrier is unavailable; this is not zero-network warm acceptance or complete#134. The earlier422 precondition failure remains preserved and its specific cause unproved."

Documentation evidence: hashed actual f4e receipt/log, unchanged source builder/harness, pinned4148c2 carrier contract above. Remaining uncertainty: docs-only successor review, final configured/hosted release gates and broader contracts. Upstream finding/disposition/link: none for RCC; expected fail-closed behavior, local Actions P1 repaired and independently accepted narrowly, no new report or external mutation.
