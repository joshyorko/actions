# Core release workflow CI portability receipt

## Immutable failure evidence

Hosted run `37966575410` on merge candidate `cdf505c9e841b1d1c8756d655aea016ffc2f9039` (PR head `da0513bf43a46e9fc203eb05025aa582615b5de0`, base `00c207fe1ebae20804056e2b17982476ee75386a`) failed package tests on macOS 15 and Windows 2022. Linux Python 3.10 passed. The failures were limited to three tests in `actions/tests/actions_core_tests/test_core_release_workflow.py`.

- macOS `test_core_artifact_inventory_and_manifest_bind_exact_bytes`, `test_core_inventory_rejects_wrong_tag_extra_and_symlink_artifacts`, and `test_core_publish_fails_closed_without_token` ran the Ubuntu release shell. BSD `find` reported `-printf: unknown primary or operator`.
- Windows failed the same three tests because `bash` resolved to the WSL launcher, which printed that no WSL distribution was installed and did not run the script.
- The workflow source pins both release jobs to `ubuntu-latest`; these failures did not exercise a supported release runner.

## Bounded repair

Added a Linux-only marker to the three tests that execute the actual Bash/GNU-utility release scripts. The structural workflow test now asserts both jobs remain pinned to `ubuntu-latest`, so platform scope is validated on all operating systems. All existing Linux execution assertions remain unchanged, including exact inventory, manifest bytes, wrong-tag/extra/symlink rejection, tamper detection, and missing-token behavior.

## Verification

Using the pinned RCC v18.19.3 gateway and the existing Core package environment:

- `CoreReleaseWorkflowTest`: 4 passed.
- `CoreTest`: 294 passed, 4 warnings.
- `CoreLint`: passed.
- `CoreTypecheck`: passed.
- `CoreDocs`: passed.
- `git diff --check`: passed.

The hosted Windows/macOS rerun is still required to verify the conditional skip on those runners. This receipt does not claim those reruns have passed.

## Helper 1.0.3 development-source reconciliation

The Core branch merged reviewed Helper version checkpoint `00beb8907243a8bf232e89c2e9822d3d881f0427` (includes only the approved 1.0.3 version/changelog update atop the separately reviewed redirect-header fix `55493f17`). Core's dev-group lock was refreshed; `actions/pyproject.toml` still declares the production helper range `^1.0.0`. The configured package environment reports Helper 1.0.3 and imports it from this worktree's `actions-http-helper/src/actions_http/__init__.py`.

After this merge, the configured Core suite again passed 294/294; the clean installed Core wheel verifier passed; Core lint, typecheck, and docs checks passed. Helper 1.0.3's exact wheel/sdist hashes and 12-test result are in the helper owner's receipt. This Core branch has not published or tagged either package.

## Hosted validation of combined head

Exact PR head `df7b0d664a661fcab5d014092f4259c32e74590f` has successful Actions Core Tests run `37970773751`: Ubuntu, macOS, and Windows all passed Test, lint, typecheck, and docs. The Windows shell-execution tests skipped per the Linux-only marker; workflow-structure assertions passed in its Test step. HTTP Helper Tests run `37970774145` passed on all three operating systems. RCC developer toolkit run `37970774070` and Actions Runtime release-build run `37970773566` were still in progress at receipt update and are outside the Core source/test gate claimed above.
