# Proposed RCC guidance clarification: upstream issue reporting

**Disposition:** proposal only; no RCC files or repository state were changed.

## Exact proposed addition

Add this paragraph under `Sources of Authority` in
`docs/agent-boundaries.md`:

> Upstream defect reports follow the target repository's current contribution
> and security guidance. Before filing, verify the consumed repository and
> revision, reproduce the defect, and search its current issues and pull
> requests. Issue creation requires explicit authority for that target and
> confirmed issue-only scope; repository access or this guidance does not grant
> it. Keep security-sensitive findings in the target's private reporting
> process. Record the report or no-report disposition and any downstream
> follow-up separately from source, build, runtime, and publication status.

## Compatibility evidence

- At RCC `main` SHA
  `47a60ea78c5d97c892177f5649a1c950399faa6a`, `docs/agent-boundaries.md`
  already allows reading and proposing while requiring explicit target and
  mutation authority for issue changes; it says repository instructions cannot
  create GitHub authority. The proposal clarifies how that boundary applies to
  upstream defect reporting without broadening permission.
- RCC `CONTRIBUTING.md` at that SHA directs contributors to search existing
  issues and open one before non-trivial changes.
- RCC `AGENTS.md` at that SHA identifies `joshyorko/rcc` as the maintained
  source and `admariner/rcc` as historical archaeology. Reports should verify
  the actual consumed fork and revision rather than assume ownership from
  lineage.
- `SECURITY.md` did not exist at that exact revision (raw path returned 404);
  the proposal defers to whatever private process the target repository
  currently documents and does not invent an RCC security channel.

The proposed paragraph itself grants no authority. The current user request
separately authorizes issue-only reporting of a confirmed new defect in the
explicitly in-scope maintained `joshyorko/rcc` repository, subject to available
permissions and RCC policy. No RCC defect was confirmed and no RCC issue was
filed during this task. The proposal is only for an RCC documentation mutation,
which remains unapproved; recheck current RCC guidance before integrating it.
