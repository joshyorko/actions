# Independent Sol CORS isolation review

Verdict: a concrete Actions-owned test isolation defect remains in PR249's failing source and in PR248's identical passing source. This defect has an exact already-integrated repair. It gives a deterministic import-order mechanism for the observed empty-allowlist WebSocket 1008 and a minimal red/green experiment. Source evidence alone does not establish the actual failing worker's import history; root dispatched the implementation/proof lane. This reviewer ran no tests, processes or signals and wrote no checkout files.

## Immutable evidence

- Failed Helper PR249 head: `00beb8907243a8bf232e89c2e9822d3d881f0427`; hosted synthetic merge: `f17bdab218800f085318f0a35f9349d4f8bb2dfc`; RCC run 37968135182, Ubuntu primary job 113947582827 and N-1 job 113947583044. Sole observed failure: assembled explicit Origin `HTTP://ALLOWED.EXAMPLE:80` handshake closes 1008. Subsequent no-Origin path is not reached.
- Passing Core PR248 synthetic merge: `f9d84917adc014a37f658f924ef397cd8e7b087a`, run37970774070. Both Action Server subtrees are `71ee52b798fc56009b713991cfb63b09a9e57dd5`; old startup-redaction test blob is `e76c91bf744145fd8a09452ed1ddf1bd6f99550d` in both.
- Prior A evidence receipt: `pr249-rcc-cors-diagnosis-20261009.json`, SHA-256 `3f142785156576695913ff2d95880bec01a1ceaefb03bd2b56123bb3170e3061`. Reports three local full passes; these do not prove isolation under every worker import order.
- Existing repair commit: `0a811f0bf981df72911c97fd59743465b19a3fff`, ancestor of reviewed convergence HEAD `3ed98ddbac3354c59414b8411b295db2e15d3545`. Its repaired startup-redaction test blob is `7852f74cbac2bc26398344ed7b09dab077b24216`; exact `git show --format= -- action_server/tests/action_server_tests/test_log_verbosity.py` patch SHA-256 `1f77fb81cb9e8e5b1e0d5b0280f521aa39c9cb824089a40cdd6c8a1a4783f602`.
- Workitems reviewed clean HEAD `00beb8907243a8bf232e89c2e9822d3d881f0427` retains the old test; prepared Action Server `.venv` exists. No new environment is necessary.

## Exact failure mechanism

At f17bdab, `test_log_verbosity.py:36` patches `_settings.get_settings` with a fake Settings accessor; line37 then string-patches `_app.get_settings`. `_app` imports `OriginPolicy, get_settings` from `_settings` at module load (line11). If `_app` was not imported previously in this pytest worker, resolution of the second dotted patch imports it while the source accessor is fake. Thus `_app.get_settings`'s recorded pre-patch value is already fake. Pytest MonkeyPatch.setattr records the resolved target's current attribute; undo restores recorded attributes in reverse order. It restores that fake to `_app`, and the real function to `_settings`. No Python from-import alias propagation occurs.

The fake Settings has default `cors_allow_origins=()`, not the later fixture's `http://allowed.example`. The CORS fixture correctly sets `_global_settings` and calls `get_app.cache_clear`, but cache clearing only removes an app result; it does not replace `_app.get_settings`. New app construction therefore reads the fake empty allowlist again. `verify_websocket_origin` at f17bdab consults `websocket.scope['app'].state.cors_origin_policy.allows(origin)` and explicitly raises1008 when false. There is no API-key dependency in this CORS fixture, so this policy branch explains the failing code/path. HTTP CORS uses the same app policy. Denied-origin tests can pass even with the leaked empty allowlist and therefore cannot establish successful configured admission.

If an earlier test on the same worker imports `_app` before the startup-redaction patch, the recorded original alias is real and teardown restores it correctly. That supplies a source-backed reason for identical code to pass or fail with different execution histories. Default xdist load scheduling divides test items into chunks across separate workers and updates assignment as workers finish. Worker globals/import/cache state are separate; another worker's passing CORS test does not prime the failing worker. The observed module split is compatible with this mechanism but does not independently prove it occurred in the hosted failure.

The global `setup_settings` context sets `_global_settings` and clears it on exit, while `get_app` is a process-local cached singleton. Both are sequential within one worker here; no source evidence of cross-worker memory mutation exists. `include_router` builds routes on each new fixture app with the explicit Origin dependency; the global SocketServer affects accepted connection state after handshake, not this policy's1008 pre-accept decision. No router dependency relaxation or origin parser change is warranted.

## Minimal deterministic proof proposed to A/root

Use a fresh process and the existing prepared package interpreter, selecting only these two test files/nodes in this order. From `workitems/action_server`:

```bash
.venv/bin/python -m pytest -n 0 -vv \
  tests/action_server_tests/test_log_verbosity.py::test_verbose_server_startup_redacts_database_url_credentials \
  tests/action_server_tests/test_server_cors.py::test_assembled_websocket_allows_effective_port_and_no_origin
```

Expected old result: startup-redaction PASS, then explicit-Origin handshake FAIL1008. This prediction has not been executed by the reviewer. Ensure the fresh process has no prior `_app` import from additional collected files/plugins; if it does, an owned scratch subprocess should explicitly assert the initial module absence and select only this sequence rather than silently treating a primed pass as disproof.

Apply ONLY the test_log_verbosity hunk from0a811f0b in the owner's repair lane and run the same pair in another fresh process. Expected2PASS. Do not compare the full convergence tree for this cause: it also changes request-origin policy. The hunk preimports `_app` and `_settings` before either patch, uses explicit module targets, and clears cached app before/after fake startup. That is the narrow existing repair. An optional reverse-order run on old code should pass because the CORS test imports `_app` first; it helps demonstrate import-order masking. A direct post-teardown identity check `_app.get_settings is _settings.get_settings` isolates the alias leak if needed. Strict allowed-origin handshake plus echo and separate no-Origin path must remain; retain denial tests unchanged.

Until exact old-red/repaired-green receipts and successor hosted gates exist, #209 remains open and the Helper gate unresolved. Local full passes, `--dist loadscope`, skips or blind retries are not a fix.

## Documentation improvement proposal

Canonical file: `docs/skills/repository-operations.md`, after the existing dependency-alias/import-order paragraph.

Exact text:

> Cache clearing cannot repair a dependency alias that teardown restored to a fake. Run the startup-redaction test followed by the explicit allowed-Origin WebSocket test in a fresh single pytest process (`-n 0`, exact node IDs in that order); running admission first can mask the defect by importing `_app` before the patch. An empty leaked allowlist still passes denied-Origin cases, so assert the constructed policy admits the exact allowed input and then require handshake and echo. Under xdist load scheduling, each worker has its own import/cache history and tests from one module may run on different workers; a passing test on another worker does not establish the failing worker's policy. Require an exact old-red/repaired-green receipt before attributing a hosted close1008 to this mechanism.

Durable learning: cache result invalidation and alias restoration are separate; denial success does not prove configured allowance; scheduling can expose an import-order defect without any source difference. Evidence: old immutable test/app/policy, installed pytest MonkeyPatch resolve/setattr/undo source and xdist LoadScheduling source, existing exact repair0a811f0b. Existing canonical warning already describes the leak; this delta adds the precise cold ordered diagnostic and worker/denial limitations, not a session diary. Remaining uncertainty: no reviewer execution, exact hosted worker import history, owner red/green result and hosted successor release gate. Root integrates or records reasoned rejection.

## Upstream disposition

Actual owner is maintained `joshyorko/actions`; this is local Actions test isolation, not a Helper or RCC defect. Existing issue #209 already tracks the exact symptom and has A's evidence comment https://github.com/joshyorko/actions/issues/209#issuecomment-6086782624. Do not file a duplicate or report scheduler/root-cause speculation as established. Root may consolidate exact reproducible repair evidence there after the owner proof under authorized issue-only scope. This reviewer made no upstream mutation, code PR, labels or assignments. Reporting link: existing #209 comment above; new report:none. Sensitive disclosure not implicated by this synthetic test-isolation finding.
