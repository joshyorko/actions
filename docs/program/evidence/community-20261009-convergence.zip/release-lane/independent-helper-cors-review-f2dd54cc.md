# Independent Helper CORS successor review

Verdict: ACCEPT exact source `f2dd54cc35798f7b689f0855b5e3d81263b1b24e`, observed clean. This accepts the narrow test-isolation repair and canonical guidance. Successor hosted gates and release admission remain separate and pending. Reviewer ran no tests or processes and did not modify the shared checkout.

## Source and artifact boundary

Exact delta from prior Helper candidate `00beb8907243a8bf232e89c2e9822d3d881f0427` SHA-256: `725115c7e8997491ac3b009baac1c4ebeb8fce1c35bd8d1b27d1e68897cfdc6b`. Only two files changed: test_log_verbosity.py (existing 11-line repair) and repository-operations.md (19 added lines). `git diff --check` passed. No production Origin parser, router, policy or Helper code changed.

The test hunk exactly adopts the prior integrated repair `0a811f0bf981df72911c97fd59743465b19a3fff`, producing the same test blob `7852f74cbac2bc26398344ed7b09dab077b24216`. It preimports alias owners before patching, patches explicit modules and clears the app cache around fake startup. This resolves the source-backed fake-get_settings alias mechanism described in sol-cors-review.md. The allowed/denied Origin checks remain strict.

Helper subtree is byte-identical at both commits: `ac9fb0da11f7d5e8ab9a53b84089fcd2a15ec1df`. Independently reopened and rehashed the retained public local artifacts built from 00beb890:

- Wheel: 14,690 bytes, SHA-256 `46ed7ce0e0d3e2e05456d937b5b24bc9dfa0d7d4b98f8119b9fdf00d4fa7e9f9`.
- Sdist: 15,302 bytes, SHA-256 `b8e4e8efb181d5748264f25f1803f47731cd4947fc015f009934d51cd7a78945`.

Both match their original build/install receipt exactly, and both embedded actions_http/__init__.py bytes match f2dd54cc source. No artifact was rebuilt; this is preserved-artifact/source-binding verification, not a claim that a future nondeterministic build will necessarily reproduce compressed bytes. No publication occurred in this lane.

## Verification records and limits

Independently read the durable configured full Action Server output at `workitems/developer/tmp/stdout.log`, SHA-256 `6e1aad211fe26680b6dbb32cb0422023806d913db01ee5f1ede510bed1d50a22`. It records Python3.12.15, pytest8.4.2, xdist3.8.0, 5-worker LoadScheduling, the package-declared invoke test-not-integration command, and441 passed/10 skipped/1 warning in62.38s. This independently confirms the saved full-suite result. The receipt source association is A's reported repaired-tree run; the output itself does not embed a Git SHA.

The ordered old RED (1 pass/1 handshake1008 failure), repaired GREEN (2 passes), Helper12 passes and Ruff/mypy passes were direct tool outputs observed by the writer/root. A explicitly disclosed that no dedicated durable logs were saved for them. They are writer/root-observed evidence, not reviewer execution or independently reopened logs. No synthetic log was created. Root informed that exact source review plus the retained full-suite record and unchanged artifact binding are sufficient for this narrow fixture change, without a repeated full suite. Fresh exact-successor hosted gates still govern release readiness; this review does not characterize old failures as transient or authorize retry/skip.

## Documentation improvement

Canonical file changed: docs/skills/repository-operations.md at f2dd54cc.

Durable learning captured: first import can capture a monkeypatched dependency accessor; teardown may restore that fake as an alias's original. Import alias owners before patching, patch both imported owners, clear cached app factories, and keep startup-redaction followed by assembled admission in one process to expose the leak. This is backed by the exact old/repaired code, pytest MonkeyPatch semantics and writer/root-observed ordered red/green.

The credential paragraph distinguishes nonempty-secret availability from authentication, scope, artifact correctness and upload readiness. It matches helper-credential-availability-attempt3.json for run37970443665 attempt3 and labels the host ghx/native-gh result as maintainer-reported, without claiming Cloud auth fixed. The immutable upstream-reporting procedure link points to57399b60496b98fea020f26e576d47bcb0d440bf.

Stale/ambiguous guidance removed: treating isolated admission success as sufficient to detect a first-import alias leak; conflating secret availability with publish readiness. Remaining uncertainty: successor hosted gates; focused/static results have no durable dedicated stdout logs. The additional exact fresh-process/worker/denial limitation paragraph in sol-cors-review.md remains proposed for root disposition, rather than silently claimed integrated.

## Upstream disposition

Confirmed local Actions-owned fixture bug, handled in PR249; no Helper/RCC/third-party defect. Existing tracker is https://github.com/joshyorko/actions/issues/209 with prior comment6086782624. Root owns one consolidated follow-up with exact repair/repro facts. No duplicate issue, comment, external code/PR, label or assignment was created by this review. Broad issue/release closure still depends on exact successor hosted results.


Root documentation disposition received: the additional fresh-process/worker/denial paragraph proposed in sol-cors-review.md is REJECTED AS DUPLICATE of f2dd54cc's committed alias/ordered-pair guidance. Root retains exact order, red/green and hosted-history limits in immutable review receipts and the existing issue follow-up https://github.com/joshyorko/actions/issues/209#issuecomment-6087143055. This is an explicit disposition, not an unresolved omission. Canonical committed repair guidance is accepted; no duplicate guide prose is required.
