# Independent review: #129 proposal-only schema probe

Reviewed checkpoint `8a052fb75d8bf7fbccf89be0a733b3a2ff2c0a59` (parent `5c3c4a6abb63a40bf00af49d16ade04c59e7cf63`) read-only. No tests, environment setup, migrations, or product commands were run.

## Verdict

The checkpoint is correctly bounded to a synthetic proposal-only schema probe, design clarification, and repository-operation guidance. The test does not import or call the application database/migration API and contains no product schema or adapter implementation. The SQLite and PostgreSQL receipts support fixture FK-parity claims only. They do not establish #129 implementation or acceptance.

One documentation blocker remains in the architecture overlay: the #129 table/JSON correctly classify it as ACTIVE and report SQLite/PostgreSQL fixture parity, but the `next_bounded_action` still says to submit the tuple/DDL proposal and receipts for review. The Markdown “Architecture-critical path” also calls #129 REVIEW, contradicting its ACTIVE row and JSON. Update the overlay before using it as a current handoff. The current worker assignment to E is consistent with the snapshot, though its label “deployment schema probe” should describe the current review stage or remain explicitly a snapshot label.

## Probe and contract review

- The 30 non-pointer and four current-pointer FK tuple declarations match the proposed scoped tuple matrix in `docs/design/deployment-revisions-draft.md`, including same-Deployment ancestry, request parent/result, package binding through the deployment-package join, provider/worker/policy references, and all four cyclic current pointers.
- SQLite introspection groups composite FKs and preserves child/parent column order. PostgreSQL introspection reads ordered constraint attribute arrays. Both tests compare the complete fixture FK graph against the same expected declarations.
- Negative rows cover cross-Deployment ancestry and current pointer, foreign-workspace/missing request parent, missing package revision, binding without its matching deployment-package row, and missing provider/worker/policy revision references. The SQLite test also confirms the intentional limit that an owner with NULL current pointer can commit; the design correctly leaves atomic owner/revision/pointer creation to the repository transaction invariant.
- PostgreSQL uses a unique `deployment_probe_<uuid>` schema, sets `search_path` to that schema, and drops only that schema in `finally`; the JUnit receipt records `postgres_schema_removed=True`. The receipt shows both SQLite and PostgreSQL tests passed with zero skips. The PostgreSQL receipt is from root-owned `postgres:17-alpine` at the recorded immutable digest.
- The test is intentionally not a production migration test: it does not exercise migration registry/upgrade paths, fresh bootstrap parity, rollback/recovery, triggers, indexes, transaction advisory locks, CAS or application-level ancestry checks. The design and guide say so explicitly.
- The probe’s `runtime_kind='rcc'` example is only a text value in a synthetic provider-grant row. No adapter class, contract method, dispatch path, product DDL, or migration was added.

## Graph and accounting review

The overlay reports 54 exact issue-body matches and manifest digest `1135e3aaf481341d5921bac7ab4ec5d726ffd2e8db0d17eaab90480e020902e8`; I independently reproduced both against the current governance ledger and retained issue snapshot. Its totals reconcile to 54 issues: READY 2, ACTIVE 5, REVIEW 11, BLOCKED 30, INTEGRATED 6, COMPLETE 0. No issue is marked COMPLETE. #129 has no merged foundation, its checkpoint PR is explicitly unmerged, and `partial_foundation=false`; #134’s merged foundation is correctly marked partial/INTEGRATED while acceptance remains open.

Closed prerequisites #80, #88, #89, #94, #95, and #137 are listed as closed and none appears in any `unresolved_open_issue_dependencies` array. For example, #99 remains blocked only on open #97/#98 acceptance. The text noting #137 in the #82 next action does not restore it as an unresolved edge.

## Required overlay correction

In both `architecture-evidence/deployment-graph-overlay.json` and `.md`:

1. Replace #129’s stale next action “Submit the exact FK tuple/ancestry/cyclic-DDL proposal and probe receipts for independent review before implementation” with “Complete independent review of the exact FK tuple matrix and two-backend proposal-only receipts; only then decide whether product DDL/migration work is ready to begin.”
2. Change the architecture-critical-path sentence “#129 is REVIEW” to “#129 is ACTIVE under worker E; its proposal-only SQLite/PostgreSQL schema probe is complete and awaiting independent design review. Product DDL/migration implementation and all full acceptance gates remain open.”
3. Update the `current_active_workers` display label for #129 from “E deployment schema probe” to the current review stage, or explicitly label it as the assignment snapshot that produced this checkpoint.

Do not change the #129 completion/accounting state on the basis of this probe: full acceptance remains zero.

## Documentation improvement

- **Canonical file changed or proposed:** `docs/skills/repository-operations.md` was improved in the checkpoint with guidance to verify process owner, command, working directory, ancestry, and receipt before signaling long-running shared processes. No further canonical-guide change is proposed from this read-only review.
- **Durable learning captured:** the proposal fixture verifies exact composite FK tuples and scoped rejection on SQLite/PostgreSQL, but cannot prove product migration or transaction behavior; a closed prerequisite is not an open dependency; design evidence does not count as full issue acceptance.
- **Evidence:** exact checkpoint source/docs; SQLite/PostgreSQL JUnit receipts; independent 54-body hash and graph count reproduction.
- **Stale or ambiguous guidance removed:** the checkpoint clarifies that PostgreSQL fixture parity and SQLite pointer behavior are synthetic probe evidence, not product behavior. The separate architecture overlay still needs the #129 stale-action/classification correction above.
- **Remaining uncertainty:** production DDL, migration upgrade/fresh bootstrap parity, migration recovery, pointer-at-commit invariants, CAS/ancestry repository behavior, triggers/indexes, authorization, resolver behavior, and complete #129 acceptance remain unimplemented or unverified.

## Follow-up disposition (2026-10-09)

After the overlay update, the scoped design-probe review is resolved with no remaining blocker to advancing #129 to its bounded exact-head design review. The overlay now classifies #129 and #151 as REVIEW, removes E and C from the active-worker set, records their submitted PR review actions, and retains ACTIVE only for A/B/D. I corrected the remaining scratch-overlay inconsistencies: downstream reason strings now identify #129 as REVIEW, and the architecture-critical-path sentence now says the proposal probe is complete and exact-head PR #245 review is next. Counts remain READY=2, ACTIVE=3, REVIEW=13, BLOCKED=30, INTEGRATED=6, COMPLETE=0; closed prerequisites remain absent from unresolved edges. This disposition does not accept the design, authorize implementation, alter dependency edges, or change issue acceptance state. Full #129 acceptance remains open.

The canonical repository guide still accurately identifies this as synthetic fixture evidence only. No further canonical-guide change is proposed. The scratch overlay correction changed only `architecture-evidence/deployment-graph-overlay.json` and `.md`; issue contract bodies, dependency edges, product source, and governance files were not changed by this review.
