# Independent review: native Work Items consumer gate

- Reviewed tree: `/workspace/work/community-resume/workitems-ci`
- Exact head: `f21fe2002c6ec29262d044313029faedc334a7cf`
- Worktree: `test/native-workitems-ci-20261009`, clean during review
- Review scope: candidate Core installation, native manifest binding, receipt behavior, OS scope and retained artifacts
- GitHub workflow run: `37960395353` (`Action Server Build (Unauthenticated)`)

## Blocker: hosted Linux runtime does not install the candidate Core wheel

The Linux job built `actions_core-1.0.2-py3-none-any.whl` successfully and invoked the native consumer step, but both packaged runtimes failed to start their synthetic action package. In the failed job logs, RCC 18.19.3's generated environment descriptor contains `python=3.12`, `uv=0.9.26`, and only `actions-work-items==0.4.4`; it does not contain the wheel path supplied under `dependencies.local-wheels`. The Runtime then imports an `actions` namespace lacking `__version__`, reports `ModuleNotFoundError: No module named 'robocorp'`, and exits before the consumer actions run. GitHub uploaded the failure receipt, and the task-owned RCC home cleanup succeeded.

The test `test_package_yaml_parser_adds_the_measured_core_wheel_as_local_dependency` proves a Python package conversion helper emits the local path. The hosted frozen/Go Runtime path instead hands the original `package.yaml` directly to bundled RCC using `ht hash` and `holotree variables` (`_action_package_handler.bootstrap_environment` → `_rcc`); the native log demonstrates this path did not install the candidate wheel. Therefore this check does not yet prove candidate Core consumption. Worker B owns the repair; this review did not alter its worktree or try a local environment.

## Other reviewed boundaries

The runner deletes any previous receipt, atomically records a fresh `IN_PROGRESS` attempt before execution, and writes `FAIL` with cases marked `NOT_VERIFIED` after ordinary acceptance failures. A deterministic subprocess regression terminates the runner while pytest is blocked and proves an old `PASS` cannot survive; final artifact mutation/interruption tests also fail closed. Proof files are created under a fresh invocation-specific directory and must match runtime identity, executable hash, Core wheel hash, exact scenario/readback schema and expected filename set before `PASS`.

When the workflow supplies the native manifest, validation binds source SHA, platform, architecture, expected package-relative executable paths and measured executable hashes, then records the manifest digest. The manifest is not a clean-source or signed attestation; executable path reads follow symlinks; candidate Core wheel provenance is outside that manifest and is represented by its separate hash/proof. These limits are documented. Optional workflow/run metadata in the manifest is not validated by the consumer runner, but it is not used as the primary content binding.

The added consumer job and candidate wheel build are limited to `ubuntu-22.04`. Existing macOS and Windows jobs passed their preexisting native tunnel, Robot and browser/history checks; the Work Items steps were skipped there. Thus this head provides no Work Items evidence for macOS or Windows. The Linux failure receipt upload and run-specific RCC-home cleanup both succeeded.

## Workflow run result

- AI audit evidence: success
- Work Items Release: success
- RCC developer toolkit: success
- macOS native binary job: success; Work Items step skipped
- Windows native binary job: success; Work Items step skipped
- Linux native binary job: failure in `Verify Work Items consumer through frozen and Go runtimes`; both package executions failed before action execution

Disposition: PR242's new Linux Work Items native acceptance gate is **not accepted** at this head. A rerun that demonstrates the candidate wheel is installed inside the Runtime-created action environment, and completes both frozen and Go-wrapper lifecycle cases with bound receipts, is required. No other blocker was established in this scoped review.
