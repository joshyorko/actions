# PR243 Linux WebSocket origin failure triage

## Scope and evidence

Read-only inspection of `workitems` at `348224f169fab5f19b0b7504d2b701237a056ef6` (PR243 head; no source edits). The checkout already had unrelated dirty paths owned by other work; they were left untouched. GitHub Actions run `37961186051` failed RCC developer toolkit Linux package tasks on both RCC 18.19.3 (job `113924127301`) and RCC 18.18.1 (job `113924127382`). Each job reports 440 passed, 1 failed, 10 skipped. The same failure is `action_server_tests/test_server_cors.py::test_assembled_websocket_allows_effective_port_and_no_origin`: opening `/api/ws` with `Origin: HTTP://ALLOWED.EXAMPLE:80` is rejected with WebSocket close code 1008. The macOS and Windows toolkit matrix jobs succeeded. The independent HTTP Helper Tests and Actions Core Tests workflows succeeded; those results do not isolate this Action Server test failure.

The failing Linux worker log shows these tests on `gw0` before the target: package tests, four `test_rcc_runtime_adapter` cases (`test_artifact_digest_parser_accepts_only_exact_identity`, `test_runtime_descriptor_has_no_activation_path_authority`, `test_import_command_uses_artifact_exec_not_python_exe`, and `test_worker_command_has_inherit_streams_and_receipt`), then the CORS rejection parameter cases for port 81, `null`, and a path. Those rejection cases pass. This is correlation only; no specific preceding test has been demonstrated to cause the failure. `gw1` also processes unrelated build-system and contract tests concurrently.

## Source facts

- `websocket_cors_app` in `action_server/tests/action_server_tests/test_server_cors.py` enters `setup_settings` with `cors_allow_origins=["http://allowed.example"]`, clears the cached `get_app()` before constructing the app and again after the test, and includes the WebSocket router with `verify_websocket_origin`.
- `get_app()` constructs a new `OriginPolicy` from current settings and stores it on `app.state.cors_origin_policy`.
- `_parse_origin` in `_settings.py` lowercases scheme and host and assigns the default HTTP port 80 when omitted. Thus the configured origin and test origin should normalize to equal `_ParsedOrigin` values. `OriginPolicy.allows` is a pure membership check with parse errors rejected.
- `verify_websocket_origin` reads the origin header and asks the WebSocket scope app's stored policy; it raises close code 1008 if that check is false.
- Repository search found no other test-side inclusion or mutation of `websocket_api_router`; the router is included by production server setup and this fixture. No source evidence yet establishes mutation of router dependencies, app state, or CORS settings by the preceding tests.

## Assessment

The source/test contract is deterministic and expects the effective-port origin to be admitted. Since the complete CORS module is reported to pass alone while the full Linux jobs fail, an in-process/order-sensitive difference remains plausible, but it is not yet proven. The source facts above do not identify a root cause, and there is no demonstrated relationship to the HTTP Helper package release. Keep the release-scoped PR free of speculative CORS changes.

## Bounded reproduction plan

When a configured Action Server test environment and disk slot are available, first rerun the exact failing node and then the CORS module to reconfirm standalone behavior. Reproduce in one worker using the same RCC/Python setup and include the observed `gw0` prefix (package tests, the four named RCC adapter cases, and preceding CORS rejection parameters). Add temporary diagnostic assertions/logging at the fixture/guard boundary for: `app.state.cors_origin_policy._allowed`, `OriginPolicy.allows("HTTP://ALLOWED.EXAMPLE:80")`, the WebSocket `scope["app"] is websocket_cors_app` identity, and the dependency list for the matched route. If these are correct immediately before connect, inspect ASGI middleware/route wiring next. Bisect that prefix before editing production code. Remove temporary diagnostics after establishing a minimal regression. No local full-suite or environment run was performed as part of this read-only triage.
