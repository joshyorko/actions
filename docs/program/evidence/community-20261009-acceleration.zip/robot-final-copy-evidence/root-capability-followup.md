# #151 next-slice root capability review (read-only)

Reviewed immutable PR #240 head `7d2563925b03bc586cef6d61876960ec1a55d4f0`, based on `5f3fbbb5d6b486373032f6136090eeb89434844e`. The implementation worktree is clean. No code, environment, or CI configuration was changed for this review.

## Current root policy and callers

Observed in `action_server/src/actions/server/_api_robots.py`:

- `ROBOTS_DIR` is a module-level constant `Path.home() / ".robots"` (line 32). No environment variable or settings field configures the Robot package store.
- ZIP import creates it with `ROBOTS_DIR.mkdir(parents=True, exist_ok=True)` (line 682); publication resolves it with `ROBOTS_DIR.resolve()` (line 443), then does collision checks, staging creation, copy, and rename by path. Robot discovery separately scans `Path.home() / ".robots"` (line 229).
- `ROBOTS_HOME` is a different setting: `get_robots_home()` in `_settings.py:323-344` describes it as RCC's home for robot executions (the holotree/cache). `_cli_impl.py:763` obtains that value. `_api_robots.py:1082` refers to the RCC home in a comment. Do not treat `ROBOTS_HOME` as the configured package-publication root.
- `ROBOTS_DIR.resolve()` follows an existing symlink to a directory; `mkdir(..., exist_ok=True)` and discovery also follow directory symlinks. I found no Robot-store symlink policy, symlink-specific test, or documentation that promises alias support. This is current path behavior, not proof that the product promises a symlink configuration feature. Rejecting symlinks would still change observed behavior, so do not add a no-follow root policy without owner review.
- On Windows, `ROBOTS_DIR` remains `Path.home()/".robots"`, while `_settings.get_robots_home()` defaults to `%LOCALAPPDATA%/robots`. These paths have different responsibilities; do not silently redirect package storage as part of a capability hardening change.

The verified #240 guide delta is committed in `docs/skills/repository-operations.md` at `7d2563925b03bc586cef6d61876960ec1a55d4f0`: copied metadata is revalidated before publication; its metadata name selects the output name absent an explicit override; this does not prove a coherent source snapshot or root identity. Evidence is in `receipt.md`, `focused-robot-api.log`, `portable-test-final.log`, and `lint-typecheck.log` in this evidence directory. Root/source capability identity and path-cleanup races remain open.

## Minimal descriptor-relative no-replace interface

A useful POSIX primitive extension is:

```python
def rename_directory_no_replace_at(
    source_parent_fd: int,
    source_name: str,
    destination_parent_fd: int,
    destination_name: str,
) -> None: ...
```

Implement it with Linux `renameat2(source_parent_fd, source_name, destination_parent_fd, destination_name, RENAME_NOREPLACE)` and macOS `renameatx_np(..., RENAME_EXCL)`. Preserve the existing `rename_directory_no_replace(Path, Path)` path behavior for Windows (`os.rename`) and make no Windows root-capability claim until a separate handle/reparse-point implementation and native tests exist. Do not fall back to replacing rename or copy publication when an exclusive native operation is unavailable.

For an integrated importer, open the selected Robot directory once and retain its directory handle. Use descriptor-relative lookup and staging-container creation, open the staging child, then rename from the child/container descriptor into the held root descriptor. If the configured root is renamed and a replacement is created at its old spelling after the descriptor is opened, this prevents the final native rename from resolving the destination through the replacement directory. It pins the opened directory object; it does not prove the initial open selected an authorized object if an attacker can mutate the namespace before admission.

This primitive alone is not an end-to-end root-capability repair. Staging directory creation and `copytree`'s destination still use pathnames today. `shutil.copytree` does not accept a destination directory descriptor, so a test swapping the root after open but before copy would still expose path redirection unless the implementation also writes the staged tree through a directory-relative copier or a platform-verified descriptor-backed path. Keep the guarantee narrowly worded until all writes, destination probes, and commit use the held directory object.

Even after all operations are directory-relative, the caller's configured spelling can be moved or rebound after the descriptor is opened. A commit can safely land in the original opened directory object while `ROBOTS_DIR / final_name` now addresses a replacement. The proof claim should be “a post-open rename/replacement cannot redirect descriptor-relative writes into the replacement”; it should not claim that the namespace spelling remains stable, the original root remains reachable, or the returned pathname stays valid under concurrent renaming.

## Concrete native regression boundary

At the primitive level, create a root and a complete staging package beneath it, open the root and staging directory descriptors, then rename the root directory to a parked name and create a replacement at the configured name with a sentinel. Call the descriptor-relative no-replace primitive using the held descriptors. Assert that the complete package appears in the parked original directory, the replacement sentinel and entries are unchanged, and the replacement receives no package. This proves post-open destination resolution is bound to the held object. It explicitly does not assert namespace-path stability or successful lookup through the old configured spelling.

For an integrated root capability, add a deterministic hook after the root and staging-container handles are retained but before the final rename; perform the same rename/replacement and assert writes/commit remain in the original object. Add a second hook after root open but before the first staging write. That second case is necessary to prove the entire publication flow is anchored; it must fail against path-based `copytree` and cannot be waived by a final-rename-only regression.

Keep the existing exclusive-collision tests: create the final entry immediately before native commit and prove it is not replaced. Keep cleanup claims independent: descriptor-relative `rmdir` protects against a replaced root spelling, but `lstat`-then-remove of a child entry remains a compare/delete race. Do not call cleanup race-free without an operation/ownership model that closes that interval.

## Safe follow-up coverage gap in PR #240

The new final-copy metadata regressions exercise `robot.yaml`. The validator also has a `package.yaml` branch (`_validate_robot_package` in `_api_robots.py`), but I found no ZIP Robot-import test of `package.yaml` in `test_api_robots.py`. A low-risk, source-independent regression is to add a valid `package.yaml` ZIP control plus a deterministic copy hook that changes the staged package's task metadata to invalid; assert import rejection, no final publication, and staging cleanup. A valid copied-name case can additionally prove output naming for this format. Propose this as a small test-only follow-up before adding branch churn; PR #240 remains at its reviewed head.

## Canonical documentation receipt for PR #240

- Canonical file changed: `docs/skills/repository-operations.md`.
- Durable learning captured: validate metadata from the completed copy and derive its destination name from that admitted copy; this does not establish a coherent source snapshot or root/source capability identity.
- Evidence: source/test changes at `7d2563925b03bc586cef6d61876960ec1a55d4f0`; 49 Robot API tests pass, configured portable task 591 pass/10 skip, Action Server lint/typecheck pass.
- Stale or ambiguous guidance removed: the guide now records final-copy metadata validation as implemented while retaining root/source identity, Windows ACL, and race-free cleanup as open.
- Remaining uncertainty: the independent source review passed per the integration owner; RCC toolkit, coverage, and unauthenticated build PR runs were still in progress at the latest check. Source snapshot coherence and all root/cleanup capability claims remain unproved.
