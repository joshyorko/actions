# Independent review: Robot final-copy metadata admission

Reviewed commit `7d2563925b03bc586cef6d61876960ec1a55d4f0` against base `5f3fbbb5d6b486373032f6136090eeb89434844e` on 2026-10-09. The implementation worktree was clean; review used immutable Git source and retained gate receipts. No source was changed and no new tests were run.

## Result

No substantive blocker found within the bounded final-copy metadata scope. `_publish_robot_package` copies into its private staging child, validates the copied tree, and uses the copied metadata name for the destination unless an explicit import name takes precedence. Invalid copied metadata raises before publication, and existing no-replace publication and identity-scoped staging cleanup remain in force.

The regressions model a valid source becoming invalid during copy and assert failure/no final package, then independently rewrite the copied metadata name and assert the final directory and API message use that copied name. Existing destination collision, no-replace and staging-cleanup regressions remain in the tested file. Retained final-code evidence reports 49 focused Robot API tests, 591 portable passes/10 skips, configured lint/typecheck and ToolkitTest 33 passed. Native CI is not established by this receipt.

Remaining gaps are material and correctly documented: copied bytes are not a coherent snapshot under a concurrent source writer; source/root capability identity, pathname cleanup against namespace races and Windows ACL isolation remain unproved. This is partial PR readiness, not acceptance of the complete #151 contract.

## Documentation receipt

`docs/skills/repository-operations.md` records the exact behavior and limits: copied metadata is validated before publication, the copied name determines naming absent an explicit override, and the change does not prove a coherent source snapshot. No additional documentation delta is proposed.
