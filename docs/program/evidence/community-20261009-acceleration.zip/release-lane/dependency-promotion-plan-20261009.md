# Helper/Core dependency promotion plan (2026-10-09)

## Decision

A dependency-only promotion to `community` can proceed independently of the unfinished Runtime and issue #134 work, but neither current broad checkpoint should be merged wholesale for that purpose. Open Core PR #217 (`review/core-checkpoint-20261008`, head `9b3c1a4bf7bbdf06481e60929ff1b40ad55a9ac2`, base `community`) contains the 1.0.2 Core API and tests alongside Runtime implementation/workflow changes. The helper 1.0.2 source delta is present in integration commit `6182db9a8ff87ff9f75f0b24ce49c18d224d499c`; no dedicated open Helper 1.0.2 PR was found. Cut package-scoped branches from the live `community` tip rather than merging the Runtime integration head.

## Minimal sequence

1. **HTTP Helper 1.0.2 PR to `community`.** Carry only the helper package delta from `6182db9a`:
   - `actions-http-helper/docs/CHANGELOG.md`
   - `actions-http-helper/pyproject.toml`
   - `actions-http-helper/src/actions_http/__init__.py`
   - `actions-http-helper/tests/test_http_helper.py`

   Also replace the legacy helper tag workflow with the hardened candidate version from release-safeguard checkpoint #215 (`d07f79b355f976f97948720474fd050d0a32ea16`), and retain its workflow contract tests (`devutils/tests/test_http_helper_release_workflow.py`). That workflow change is isolated/manual: the repo generator has no Helper Release target, so no unrelated generated Runtime workflow changes are required. The old `community` helper release workflow installs, builds, and publishes directly from a tag without the newer exact inventory, retained artifact hash check, community ancestry/version proof, or explicit missing-secret guard.

2. **Core 1.0.2 PR to `community`, after Helper is merged and PyPI-visible.** Select the Core package/public-API source and tests from PR #217 (`9b3c1a4`), plus only necessary Core API doc-generation support (`devutils/src/devutils/docs.py`, `devutils/src/devutils/invoke_utils.py`, and `devutils/tests/test_docs.py`). Exclude `action_server/**`, Runtime release workflow/generator changes, Runtime changelog, and Runtime-specific candidate-wheel install machinery. Keep `actions/docs/CHANGELOG.md`, API docs, `actions/pyproject.toml`, `actions/src/actions/{__init__.py,server_integration.py}`, and Core package tests. The existing Core tag workflow is hand-authored (not the Runtime workflow generator). It checks tag version, builds, strict-Twine-checks, runs the clean-wheel verifier, uploads the verified artifact, then verifies community ancestry and tag/package version before publishing the downloaded artifact. A stronger exact artifact inventory/hash manifest is absent; add it only if the root chooses to make that release-integrity invariant required for Core too.

3. **Tag each exact merged `community` commit only after its PR CI and release build gates pass.** Helper tag pattern is `actions_http-1.0.2`; Core tag pattern is `actions-core-1.0.2`. Confirm registry version and exact artifacts after each publish before allowing Runtime 1.0.3's tag workflow. Runtime 1.0.3 declares floors Helper `^1.0.2`, Core `^1.0.2`, Work Items `^0.4.4`; Work Items 0.4.4 being live satisfies only that package floor and does not complete issue #208's contract.

## Candidate package evidence run locally

Pinned RCC 18.19.3 Python 3.12.15 and Poetry 2.1.1 were used. Candidate source was the current tested integration tree; these results are wheel/package evidence, not a community PR admission or authorization to publish.

- Helper 1.0.2: `poetry check --lock` passed (metadata deprecation warnings only); built exactly `actions_http_helper-1.0.2-py3-none-any.whl` and `actions_http_helper-1.0.2.tar.gz`; Twine 6.2.0 `check --strict` passed for both. In a fresh Python 3.12 venv, installed the built wheel from outside the checkout and ran the full helper test file against the installed distribution: **11 passed**. Imported package path was the temporary venv's `site-packages`.
- Core 1.0.2: `poetry check --lock` passed (metadata deprecation warnings only); built exactly `actions_core-1.0.2-py3-none-any.whl` and `actions_core-1.0.2.tar.gz`; Twine 6.2.0 `check --strict` passed for both. The release workflow's `actions/scripts/verify_clean_wheel.py` passed on the wheel. Core package tests passed **115/115**. Candidate Core wheel workflow/installer contract tests passed **5/5**.
- PR #217's original hosted checks were all successful at exact head `9b3c1a4`; these prove that broad PR head, not the proposed package-only re-cut. The package-only branches still need their own exact-head hosted admission checks.
- No tags or PyPI versions were created. Both candidate package wheels are ephemeral local build outputs, not retained release artifacts.

## Required gates still missing

- Separate package-only candidate PR heads based on the then-current `community` tip and successful hosted PR CI for those exact heads.
- For Helper: hardened community-visible tag workflow must be merged first; the existing community helper tag workflow is not sufficient to claim the strengthened publication safeguards. Tag-triggered verify/publish remains intentionally unrun.
- For Core: no separate package-only admission run exists. Its current community tag workflow is viable for a release but lacks a strict two-file inventory/hash recheck after artifact download; decide and review that integrity addition before calling the candidate complete.
- Registry publication, artifact hashes, and clean install of the published releases remain future post-merge gates. They were not performed here.

## Exact canonical guide delta proposed

Append this paragraph to `docs/skills/repository-operations.md` under **Integrating checkpoints before publication**, after the warning that PR candidate dependency wheels are verification-only:

> When a prerequisite distribution must ship before a broader Runtime checkpoint, create a Community-targeted promotion PR containing only that distribution's versioned package source, changelog, package tests, and release workflow, plus developer documentation support required by that package. Do not merge a mixed Runtime integration head merely to make its dependency version available. Run package build, exact artifact and metadata checks, strict Twine validation, and clean installed-wheel tests against the exact promotion PR head. After merge, release only from the exact community-ancestral version tag and verify registry artifacts before promoting the next dependent package. Preserve any issue acceptance contract separately; an already-published package version does not by itself close a broader issue.

This encodes the concrete lesson from #217/integration: Core and Helper code can be promoted without waiting for Runtime, but the original code histories are broader than the safe dependency-only release slice.

Local artifact hashes (for identifying this ephemeral verification run only):

- Helper wheel `actions_http_helper-1.0.2-py3-none-any.whl`: `ca7ef1d4b15dff983855107e56a6d07bde5454770d0ac8ef0e2bdb6bf3e146e0`
- Helper sdist `actions_http_helper-1.0.2.tar.gz`: `424487884d346f05e1228aeb6fcc8ecf4ce4c975e7302bfd9f3efd4f53f68ff8`
- Core wheel `actions_core-1.0.2-py3-none-any.whl`: `9d527edf540978172178894546add75f117f240786aec804cb75c308615a7e80`
- Core sdist `actions_core-1.0.2.tar.gz`: `1c763285dcf9238139692b60117758a4d420b2c4d15c8bd6c44a854fb9656601`
