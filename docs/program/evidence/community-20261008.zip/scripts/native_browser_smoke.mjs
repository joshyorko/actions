import { chromium } from '/workspace/work/community-program/runtime/action_server/frontend/node_modules/playwright/index.mjs';
const browser = await chromium.launch({executablePath:'/workspace/actions-cloud/cache/playwright/chromium-1234/chrome-linux64/chrome', headless:true, args:['--no-sandbox']});
try {
  const page = await browser.newPage();
  const errors = [];
  const failures = [];
  page.on('pageerror', e => errors.push(e.message.slice(0,160)));
  page.on('response', r => {if(r.status() >= 400 && new URL(r.url()).pathname.startsWith('/api/')) failures.push({path:new URL(r.url()).pathname,status:r.status()});});
  await page.goto(process.argv[2]+'/runs', {waitUntil:'networkidle'});
  await page.waitForTimeout(1000);
  const result = {mode:process.argv[3], browser:'cached Chromium1234', page_errors:errors, api_failures:failures, has_runs_text:await page.getByText('Runs',{exact:true}).count()>0, body_excerpt:(await page.locator('body').innerText()).slice(0,300)};
  console.log(JSON.stringify(result));
} finally {await browser.close();}
