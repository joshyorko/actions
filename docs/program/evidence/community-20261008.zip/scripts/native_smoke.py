import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import time
import urllib.error
import urllib.request

root = Path('/workspace/work/community-program')
binary = root / 'runtime/action_server/dist/action-server/action-server'
node = Path('/workspace/actions-cloud/robocorp/holotree/c2fd1aa_5a1fac3_9fcd2534/bin/node')
receipt = {'source_head':'0a811f0bf981df72911c97fd59743465b19a3fff', 'generated_static':'working tree from repository build-frontend; not yet committed', 'platform':'Linux', 'frozen_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(), 'go_wrapper_sha256':hashlib.sha256((root/'runtime/action_server/dist/final/action-server').read_bytes()).hexdigest(), 'cases':[]}
for mode in ('local-no-key', 'configured-key'):
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0))
        port = sock.getsockname()[1]
    url = f'http://127.0.0.1:{port}'
    key = 'synthetic-validation-key' if mode == 'configured-key' else 'None'
    datadir = root / ('native-data-'+mode)
    datadir.mkdir(exist_ok=True)
    env = os.environ.copy()
    for name in ('PYTHONPATH','PYTHONHOME','VIRTUAL_ENV'):
        env.pop(name,None)
    env['ACTIONS_SKIP_UPDATE_CHECK']='1'
    log = (root/'evidence'/('native-start-'+mode+'.log')).open('w')
    command = [str(binary),'start','--address','127.0.0.1','--port',str(port),'--datadir',str(datadir),'--actions-sync=false']
    if mode == 'configured-key':
        command += ['--api-key',key]
    process = subprocess.Popen(command,cwd=datadir,env=env,stdout=log,stderr=subprocess.STDOUT)
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        for _ in range(100):
            try:
                opener.open(url+'/config',timeout=1).close()
                break
            except (OSError,urllib.error.URLError):
                if process.poll() is not None:
                    raise RuntimeError('Frozen Runtime startup failed; see evidence log')
                time.sleep(.1)
        headers = {'Authorization':'Bearer '+key} if mode=='configured-key' else {}
        item = {'mode':mode}
        for path in ('/api/runs/summary','/api/work-items'):
            try:
                with opener.open(urllib.request.Request(url+path,headers=headers),timeout=10) as response:
                    item[path]={'status':response.status,'bytes':len(response.read())}
            except urllib.error.HTTPError as e:
                item[path]={'status':e.code}
        completed = subprocess.run([str(node),str(root/'native_browser_smoke.mjs'),url,mode],capture_output=True,text=True,timeout=45,env=env)
        item['browser_exit']=completed.returncode
        if completed.returncode:
            item['browser_error']=completed.stderr[-1500:]
        else:
            item['browser']=json.loads(completed.stdout)
        receipt['cases'].append(item)
    finally:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        log.close()
(root/'evidence/native-browser-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
