# History and selected-navigation review

Exact integration head `949d4a5e876269132976eddbaef8f483eed24648`, relative7c45029b. No production edits or publication.

No actionable finding in the bounded mobile-navigation change: Link click explicitly invokes the layout close callback even when choosing the already active route, independent of route-change effects. This preserves normal navigation and closes the overlay/current-route interaction.

History harness review: synthetic210 results of4MiB each exceed867MB; seeded only in temporary SQLite storage while Runtime stopped. Browser uses actual authentication, bounded summary routes, pagination and a closed/reopened real summary WebSocket; it verifies page refresh after reconnect, rejects legacy /api/runs requests, checks summaries omit result/inputs and remain under1MiB/200rows. Explicit bearer detail retrieval proves retained full payload retrieval separately. Processes use reviewed owned cleanup, API key enters browser through stdin, result receipts contain no payload/key, and temporary data/logs are removed. Hosted matrix invokes harness for native products.

Receipt readback: both native-large-history.json and native-large-history-final.json report PASS for frozen/Go and source SHA119b4f118bddb999ab1fc31b6edc5dd7fca36209. These are119 binary proofs, not949 mobile artifact validation; do not use filenames 'final' to override their recorded source identity. Frozen digest is executable-only and history harness does not rehash after execution; maintain that provenance limitation. Instrumented browser bodies are measured after read; this is regression evidence rather than proof the harness itself streams arbitrarily oversized failed responses safely.

NOT_RUN by reviewer: full native history rerun, refreshed949 native binaries, all-OS runs. Retained error-state/accessibility/offline/native-worker/liveTLS/no-follow acceptance remains distinct. No automatic release approval.

Documentation improvement:
- Canonical file changed or proposed: docs/skills/repository-operations.md large history/native verification section.
- Durable learning captured: Proposed addition: "For navigation overlays, selecting the current route must close the menu without relying on a route-change effect. Native receipt filenames are descriptive only; artifact build SHA and checksum determine evidence identity. New frontend production changes require rebuilding and validating embedded/native artifacts even when an older build passes a newer harness."
- Evidence: exact Link/layout callback delta; native history source assertions; two119-source receipts read back; focused runtime-shell test receipt communicated separately.
- Stale or ambiguous guidance removed: treating current-route clicks as route changes or a 'final' receipt filename as proof of the latest source.
- Remaining uncertainty: new949 artifact build/platform validation and remaining whole-issue cells.
