# PostgreSQL transaction ownership review

Exact source `8524e9c3e9bc35bfc17f70f887d9d0b680856af3`. No actionable finding in bounded patch review.

PostgreSQL connects in autocommit mode and enters conn.transaction for each explicit outer Database.transaction, preventing an earlier standalone read from silently opening the transaction that a subsequent manual BEGIN duplicates. Existing explicit nested SAVEPOINT rollback behavior is retained; SQLite outer BEGIN/commit/rollback semantics remain unchanged. Mutation execute/update-returning methods still require the abstraction's transaction state. Migration transaction-scoped advisory lock is acquired inside the explicit root boundary; scheduler session claims use their separate autocommit connection and retain lifetime/health handling. Raw BEGIN/commit/rollback production callers were inspected; unrelated vendored cache SQLite commits do not use this Database.

Independently ran complete test_database.py and test_database_shared.py with explicit candidate source path:53PASS12PostgreSQLSKIP. This is a portable independent verification, not the live PostgreSQL receipt. Retained real PostgreSQL+SQLite final log records65PASS with no skips; postgres-final.log contains no redundant-BEGIN warnings in the inspected output. New real-PostgreSQL test checks nested rollback, outer rollback, commit visibility, IDLE connection status after read, and notice absence. Owned service already removed, so its65PASS is receipt/source reviewed rather than independently rerun.

NOT_RUN: native/wheel/sdist/PostgreSQL TLS/mixed-version rollout, complete lease/epoch fencing, successful distributed worker continuation and final candidate full RCC gates. Whole #84 acceptance remains unfinished.

Documentation improvement:
- Canonical file changed or proposed: docs/skills/repository-operations.md shared database transaction guidance.
- Durable learning captured: Proposed addition: "PostgreSQL connections use autocommit for standalone reads, while Database.transaction owns the outer transaction through psycopg's transaction context and retains nested savepoint semantics. Inspect driver transaction status/notices alongside commit/rollback results; a redundant-BEGIN warning can indicate an earlier implicit transaction, not harmless duplicate SQL. Transaction-scoped and session-scoped advisory locks must stay attached to their intended connection lifetime."
- Evidence: exact autocommit/transaction patch; caller/lock inspection; independent53PASS12SKIP; retained real65PASS and warning-free final log.
- Stale or ambiguous guidance removed: treating manual BEGIN on implicit driver transactions as correct ownership or silently ignoring those warnings.
- Remaining uncertainty: independently repeated real PostgreSQL/native/package/version acceptance cells above.
