# Tunnel ownership successor review

Exact checkpoint `f076425d750e468f980365eeefe467542affb337`. Read-only review and focused diagnostics with explicit candidate source path.

Prior three bounded ownership findings resolved: post-start signal/callback setup now sits inside nested cleanup finally blocks; URL acquisition failures/cancellation call per-provider stop/reap before raising; SSH executor reads have a remaining-deadline wait_for and terminating/closing the owned provider unblocks the reader. Independent complete provider/lifecycle files25PASS. Additional safe real-child diagnostic substituted a quiet local Python process for SSH without network:0.15second deadline completed in0.16seconds, child reaped and stdout closed. This is actual quiet-pipe cancellation proof, not real provider/public-edge conformance.

State policy improved: existing path components reject symlink/reparse entries via lstat, POSIX home/state ownership and private mode enforced, state opened with O_NOFOLLOW when available and fstat before JSON parsing. These checks do not constitute race-free directory-handle no-follow publication/removal, native Windows ACL/handle policy or bounded corrupted-file JSON proof. Preserve those acceptance gaps rather than describing universal filesystem safety.

No new actionable finding identified in this bounded repair. #214 remains incomplete: public-edge identity/auth forwarding unproved; SSH still disables host-key verification; Cloudflare token is in argv; configured URL is only syntax-checked, not bound to tunnel identity; Windows pipe/native provider behavior unproved; lifecycle and legacy --expose remain separate controllers. Status honestly remains starting until edge proof. No recommendation to integrate or release the unfinished exposure capability.

Documentation improvement:
- Canonical file changed or proposed: docs/skills/repository-operations.md provider ownership/verification guidance.
- Durable learning captured: Proposed addition: "A bounded pipe timeout must also terminate/reap the owner and unblock the reader before executor shutdown. Prove this with a quiet real child in addition to mocked provider failure tests. No-follow final-file opens and private directory checks are separate from directory-race, Windows ACL and live edge identity proof."
- Evidence: complete25PASS; real quiet-child0.16second cancellation/reaping; exact nested cleanup and no-follow state source inspection.
- Stale or ambiguous guidance removed: loop deadline without bounded read, failure-only mocks as actual pipe cancellation proof, starting status as readiness.
- Remaining uncertainty: edge/security/platform/state/controller cells above; full #214 acceptance and release remain blocked.
