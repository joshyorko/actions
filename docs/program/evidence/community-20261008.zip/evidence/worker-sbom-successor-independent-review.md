# Worker and SBOM successor review

Exact head `d1c07b88694f860f6d1e1d9cb648b38e99a388f2`. Read-only source inspection and focused existing-environment diagnostics; no production edit, merge, or publication.

Verdict: no actionable finding in this bounded successor. Older Core compatibility is now explicitly unsupported by the new worker public integration contract and fails with an actionable upgrade/rebuild message rather than silently losing managed Request. This is an intentional compatibility requirement, not proof of backwards-compatible execution.

PASS: independently loaded Actions from the downloaded published Core1.0.1 wheel installation at `/workspace/work/community-program/published-core-probe/site`, confirmed its origin and metadata1.0.1, restricted its namespace search to that published package directory, confirmed server_integration absent, and loaded the candidate worker directly using importlib.util. Plugin construction raises the expected RuntimeError containing installed1.0.1 and required>=1.0.2. Without namespace isolation, the Runtime Poetry environment's editable Core directory appears in Actions' pkgutil __path__, allowing the new integration module to be accidentally imported despite the old package's __file__ and metadata; that first probe is invalid wheel-compatibility evidence.

PASS: parsed all four nested template archives in the embedded action-templates.zip and verified each package.yaml pins Core1.0.2. Source guards permit deprecated Robocorp fallback only when the Actions Core distribution is absent. Candidate publication remains conditional on prior Core workflow publication and verification.

PASS: independently ran the SBOM determinism regression, 1 test passing. It runs the actual installed generator/package scripts, proves an unowned residual node_modules subtree does not alter either retained SBOM, and proves a declared locked dependency remains represented. --package-lock-only changes inventory semantics to the committed dependency graph; canonical documentation explicitly states this is not the exact bundled-module inventory and preserves full-file hosted comparisons. No validator or release-admission weakening appears in this delta.

NOT_RUN: full cross-platform determinism builds, candidate worker native execution, pre-existing packages migrated and executed, graph acceptance or publication. Prior Linux native create/list/detail receipt remains separate from worker execution/state-transition proof.

Documentation improvement:
- Canonical file changed or proposed: docs/skills/repository-operations.md, Worker Core compatibility admission section.
- Durable learning captured: Proposed addition: "Installed-wheel probes must inspect every namespace search path, not only module __file__ and distribution metadata. Actions uses pkgutil extension paths; an editable Core checkout can satisfy a missing module from an older wheel. Run outside editable installations or restrict the test namespace to the inspected wheel before claiming old-wheel contract rejection or compatibility."
- Evidence: first contaminated probe accepted Core1.0.1; isolated published-wheel probe correctly raised actionable version failure; embedded template checks; real-generator SBOM1PASS.
- Stale or ambiguous guidance removed: assuming package origin and version metadata alone prove clean wheel isolation.
- Remaining uncertainty: complete candidate/retained-version execution, native state transitions and cross-platform artifact determinism remain separate acceptance cells.
