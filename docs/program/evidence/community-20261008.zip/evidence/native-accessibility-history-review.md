# Native accessibility and history-cleanup review

Exact harness source `06c62be524ee259688db068e22548a17851c01e3`, including history cleanup3190cb53. Read-only source/receipt review; no complete native rerun by reviewer.

No actionable finding in bounded changes. SQLite fixture connection now exits the transaction before closing via contextlib.closing; successful commit and failure rollback are retained, and the handle is released before temporary cleanup on Windows. Temporary root resolves benign platform aliases before creating project/data, consistent with the separately reviewed artifact link policy. Failure receipt exposes bounded phase/type and existing sanitized diagnostics rather than raw responses, paths, credentials or logs.

Accessibility uses actual axe-core on the real packaged page, waits fonts and finite running animations rather than disabling CSS/rules, and asserts zero violations for WCAG2A/AA and2.1A/AA tagged rules at sign-in, empty queue, create dialog and detail dialog. A deliberately low-contrast native-page fixture must trigger color-contrast and is removed before positive audits. No contrast-rule exclusion or assertion relaxation is introduced. Violation receipts contain only rule IDs/impact/counts; failure normalization accepts bounded identifier-shaped rule names. This is automated four-state Chromium proof, not WCAG conformance/manual/full-route/mobile accessibility acceptance. Incomplete axe checks are not asserted absent, so manual uncertainty remains material.

Receipt identities independently read: native-history-cleanup-green.json and native-accessibility-settled.json both PASS frozen/Go at source119b4f118bddb999ab1fc31b6edc5dd7fca36209. They validate119 binaries under newer harnesses, not newly built06 binaries. Earlier native-accessibility-rules-red.json preserves FAIL and its original IN_PROGRESS case; do not retroactively label it product CSS failure. No product CSS changed, and later unsynchronized passing evidence means transient audit timing is plausible but not conclusively causal. Current settling strengthens deterministic observation without establishing the original failure cause.

Retained platform account: Windows/macOS browser-storage PASS and historical Windows history cleanup/macOS alias failures are separate receipts; source correction and Linux green cannot replace their exact updated hosted reruns. Live TLS, worker state transitions, attachments, manual/full-route/browser-matrix accessibility and no-follow races remain unproved.

Documentation improvement:
- Canonical file changed or proposed: docs/skills/work-items.md automated native accessibility, and repository-operations history cleanup guidance.
- Durable learning captured: Proposed addition: "Axe failures during transitions must retain their failed receipt; settle finite animations/fonts and prove contrast detection with a negative control without disabling rules or claiming an unproven product CSS root cause. SQLite connection context commits/rolls back but does not close the handle; native temporary cleanup requires explicit closing. Record artifact build SHA separately from harness SHA."
- Evidence: exact cleanup/audit diffs;119-subject PASS/FAIL receipt readback; no rules disabled.
- Stale or ambiguous guidance removed: all-accessibility claims from four automatic states, context-managed SQLite connection as automatically closed, transient contrast failure automatically attributed to shipped CSS.
- Remaining uncertainty: exact updated platform reruns and complete accessibility/security/platform acceptance.
