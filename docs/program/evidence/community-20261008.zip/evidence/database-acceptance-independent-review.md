# Shared database source receipt review (#84)

Read-only evidence/source review at worktree head `9e15494730878b82df4831bcad32ab44f24415c9`. No tracked changes present. Did not create another database or rerun the retired service.

Receipt readback: pytest-db-sanitized.log records64PASS in21.57s, with no skips reported. Image record binds PostgreSQL to postgres@sha256:ca0bd484cb98bf4b24eb1010e73fb3fcbd6714d240fbc1a10eea5b7dbecb641d (local image sha275447c9...). Owned cleanup record names actions-community-db84-20261008 and records verified removal. These are retained execution records, not an independently witnessed rerun.

Source inspection confirms PostgreSQL-enabled tests perform real shared Database transactions/rollback, atomic concurrent updates, native JSON operators/arrays, schema introspection, legacy output preservation/rerun, unequal archive collision abort/operator repair/retry, and concurrent migration startup. The independent Runtime-process schedule test starts two distinct Python subprocesses with real Settings, database load, process pool and SchedulerEngine, synchronizes them at a barrier and proves exactly one schedule_execution and one Run. It allows either completed or failed execution status, so this proves safe competing scheduler admission, not successful distributed action execution. Concurrent migration cases use two separate database connections/threads; they are not independently launched full server replicas. SQLite controls exist in the same shared source suite; full fresh/upgrade/native/version cells must remain individually accounted.

Retained receipt screen found zero database-URL/password/Authorization/Bearer pattern hits across its text/log files; this is a limited credential screen, not a blanket exhaustive secret-containment proof. Raw database URL was not printed. PostgreSQL log contains repeated 'already a transaction in progress' warnings; tests remained passing, but preserve those warnings and assess separately rather than claiming warning-free execution.

NOT_RUN/unproved here: wheel/sdist clean installs, native/frozen/migration CLI/server startup with PostgreSQL, database TLS negotiation and production proxy/network topology, mixed Runtime/schema rolling-upgrade matrix, connection-loss authoritative-state guarantees beyond existing focused tests, #83 DB-time lease/epoch fencing, full durable/distributed vertical. Whole #84 acceptance is not granted by64source tests.

Documentation improvement:
- Canonical file changed or proposed: docs/skills/repository-operations.md Action Server shared database verification.
- Durable learning captured: Proposed addition: "Record service image digest, exact source SHA, selected suite, retained sanitized output and owned cleanup independently. Two real scheduler subprocesses proving one admission do not establish successful distributed execution when the assertion permits a failed Run. Threaded migration-connection tests are distinct from independent server-process startup, and source PostgreSQL tests do not prove wheel/native/TLS/rolling-upgrade acceptance."
- Evidence:64PASS receipt; pinned image and removal records; independent-process, migration and collision source assertions; limited credential screen.
- Stale or ambiguous guidance removed: treating source DB acceptance as complete distributed Runtime or native PostgreSQL compatibility proof.
- Remaining uncertainty: distribution/platform/TLS/version/lease cells and interpretation of transaction warnings.
