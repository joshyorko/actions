# Windows Job drain review

Exact `8164742a8d9b29fb72b62f071dc391708e9e3a8a`. Read-only source inspection and existing Runtime interpreter validation.

No actionable production finding in bounded Job-drain implementation. QueryInformationJobObject BasicAccounting class1 uses the correct four LARGE_INTEGER-equivalent64bit time fields plus four DWORD counters; WinAPI HANDLE/BOOL/UINT/pointer/size signatures match the used calls. TerminateJobObject initiates owned-tree termination, bounded monotonic active-count loop observes zero before return, and Job closes in finally even if query/terminate/wait fails. No unrelated process-name termination or cleanup fallback is added; gate ownership remains intact.

Actionable test proof gap: actual Windows held-file regression still calls WaitForSingleObject(handle,5000) after owned_process exits, before unlink. The old asynchronous close can drain during that five-second allowance, so this does not demonstrate all descendants exited before context return. Assert Wait(handle,0)==0 immediately after leaving the context, then unlink; keep bounded wait only for failure cleanup. Actual native Windows RED/green evidence remains required.

Independent portable suite6PASS2WindowsSKIP. Mock count-loop tests prove polling/deadline control flow, not real WinAPI termination timing. Full CheckAll run in fresh environment and12Core-format failures are not attributed to this two-script patch without baseline reproduction; retain original failed output separately rather than claiming that gate passes.

Documentation improvement:
- Canonical file changed or proposed: docs/skills/work-items.md native ownership/drain guidance.
- Durable learning captured: Proposed addition: "Kill-on-close is asynchronous; wait for zero owned active processes before temporary resource cleanup. To prove completion before returning, native regression must check the descendant handle with zero timeout immediately after the context, without a subsequent wait that masks the missing synchronization."
- Evidence: exact WinAPI structures/calls and finally paths; independent6PASS2SKIP; held-file test ordering inspection.
- Stale or ambiguous guidance removed: eventual termination after a five-second test wait as proof of synchronous cleanup completion.
- Remaining uncertainty: stricter actual Windows regression, hosted cleanup proof, fresh-env broad gate attribution.
