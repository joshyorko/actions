# Robot publication boundary: unresolved release blocker

Reviewed source: 06c62be524ee259688db068e22548a17851c01e3, `_api_robots.py:_publish_robot_package`.
Contracts: GitHub #151 output-root traversal/link races, complete atomic publication and safe cleanup; #148 no overwrite, source mutation resistance and platform parity.

## Executable evidence

Run using the prepared Runtime Poetry environment:

`poetry run pytest /workspace/work/community-program/evidence/robot-publication-races/test_robot_publication_races.py -q --disable-warnings`

The test injects a competing filesystem operation at a deterministic call boundary, then invokes the real `copytree`/`os.replace`. It does not mock success, kernel return values, or the asserted filesystem state. All content, roots and outside directories are temporary synthetic fixtures. These are actual Linux filesystem mechanism probes, not Windows/macOS runtime evidence or complete remote-route exploit demonstrations. A concurrent local actor must be able to modify the publication parent; an archive alone has not been shown to cause these interleavings.

- Valid complete publication control passes.
- A competing empty final directory created after the final `lexists` check is replaced by `os.replace` on Linux; inode identity changes and package files appear in the existing directory name.
- Renaming the admitted Robot root and replacing its path with a symlink before `copytree` publishes the package into a separate temporary outside directory. Resolving the root once does not pin directory identity.
- Creating the randomly chosen staging directory before `copytree` causes `FileExistsError`, but the unconditional final cleanup deletes that foreign directory and its sentinel. The importer never created or owned that staging entry.

## Required enforceable design

A complete fix needs a filesystem publication primitive with all of these properties, not another sequence of path checks:

1. Open and retain the admitted destination root through a no-follow directory handle; reject reparse/link ancestors under the platform policy. Keep parent identity stable for every operation.
2. Allocate a private staging directory relative to that retained handle using exclusive creation. Record ownership only after success. Copy and validate using relative handles/no-follow opens, or an equivalently reviewed immutable snapshot mechanism; `copytree` against a replaceable absolute parent is insufficient.
3. Publish the complete directory using an atomic **no-replace** rename relative to the same retained destination handle. Retry collisions without modifying the competing entry. Linux `renameat2(..., RENAME_NOREPLACE)` is available in the current environment; POSIX `os.rename`/`os.replace` alone do not offer this contract. macOS exclusive rename and Windows handle-relative rename require separate implementation and native proof, including junctions and sharing semantics.
4. Cleanup must operate on the exact owned staging identity and retained parent; never delete an entry merely because its random pathname currently exists. Swapped staging entries must remain outside cleanup authority.
5. Unsupported kernel/filesystem primitives must fail admission explicitly. They must not fall back to overwriting rename, early visible final-directory reservations, or platform-skipped security checks.

A final-path `mkdir` reservation would expose incomplete authoritative directories. Advisory locks coordinate cooperative importers but do not enforce the stated hostile path-race contract. A Linux-only fix cannot establish the supported three-platform release cell.

## Canonical guide proposal

Append to `docs/skills/repository-operations.md`, beside the Robot source-admission guidance:

> Robot publication requires more than `resolve`, `lexists`, tree validation and an atomic replacing rename. Retain destination-directory identity through handles, allocate staging exclusively, publish complete content with a kernel no-replace operation, and clean only staging entries whose ownership is established. A name collision is not permission to delete or overwrite that entry. Prove competing destination creation, root replacement and staging replacement on each supported native filesystem. Until those proofs pass, keep #151's output-root race acceptance and the associated release gate open; ordinary ZIP, download and browser success do not close it.

No production change was made: the portable handle/copy/rename/cleanup contract is not available as a single Python standard-library primitive, and a partial path-precheck patch would misstate the security result.

## Bounded correction checkpoint

The initial staging collision has a separate, locally provable correction: create the staging directory exclusively with mode 0700, record ownership only after successful creation, then copy into it. Cleanup runs only for a directory this call successfully allocated. The real `os.mkdir` interleaving regression was RED (foreign sentinel deleted) and the complete Robot API selection is now GREEN (40 tests), including interrupted-copy cleanup. This ownership flag does **not** prove that a later same-UID replacement cannot occur and does not resolve output-root replacement or final destination overwrite.

The narrower intended admission model is a Runtime-owned source/publication namespace inaccessible to an untrusted different-principal actor, with cooperative service writers serialized. Arbitrary same-UID compromise is not an archive sandbox guarantee. Under that declared model, private staging plus destination identity pinning and kernel exclusive publication can be sufficient; descriptor-relative copying of every file is not uniquely necessary. Admission must actually verify the permission model: POSIX ownership/mode and ancestor replacement rights, or native Windows ACLs including parent DELETE_CHILD, target DELETE and reparse semantics. Translating POSIX mode tests to Windows is insufficient. This repository has no existing native ACL/exclusive-directory-rename helper to reuse.

Canonical guide addition for the bounded correction:

> Create Robot publication staging exclusively before copying, and record ownership only after allocation succeeds. Never clean an initial colliding entry. This protects initial ownership, not subsequent hostile name replacement. Keep the output-root and final no-overwrite race gates open until native permission admission, destination identity pinning and exclusive publication are verified for the declared threat model.

## Atomic no-replace correction checkpoint

The new `_directory_publication.rename_directory_no_replace` helper uses Linux `renameat2(RENAME_NOREPLACE)` and macOS `renameatx_np(RENAME_EXCL)`. On Windows it uses `os.rename`: Python documents that an existing destination always raises `FileExistsError`, and CPython implements that branch with `MoveFileExW` without `MOVEFILE_REPLACE_EXISTING`. Source: https://docs.python.org/3/library/os.html#os.rename . Windows documentation is rationale, not native execution proof.

The helper has no copy, replacing-rename or final-directory reservation fallback. Unsupported platforms, missing libc symbols, unsupported kernels/filesystems and cross-device publication fail. Complete-directory success and empty-directory/nonempty-directory/file collision preservation are exercised through the actual platform primitive without platform skips. Linux execution is GREEN; macOS and Windows are NOT_RUN for this implementation until their hosted jobs pass. The legacy `actions_runtime_tests.yml` matrix does not trigger on the current community/integration branches; root must wire these tests into the active native workflow instead.

The production regression creates a competing empty directory immediately after the final `lexists` observation and before the real rename. At 096292b3 it was RED because the directory inode was overwritten. The new helper preserves that inode and empty content, retries a unique final name and publishes the complete package there. Focused Robot/helper suite: 50 PASS; Ruff and Mypy (2 production files) PASS. Receipts: `no-replace-red.log`, `no-replace-green.log`.

This closes the bounded destination-overwrite mechanism on tested Linux. It does not close output-root replacement, source mutation or subsequent staging replacement, and does not establish permission/ACL admission. #151 remains open.

Canonical guide proposal for `docs/skills/repository-operations.md`:

> Robot publication uses a native atomic no-replace directory rename, not `lexists` followed by a replacing rename. Linux requires `renameat2(RENAME_NOREPLACE)`; macOS requires `renameatx_np(RENAME_EXCL)`; Windows uses documented `os.rename` collision semantics. Unsupported operations and cross-device moves fail admission without copy/replace fallback. Test complete publication and competing empty/nonempty/file destinations on each native platform. Keep destination collision evidence separate from output-root identity, protected-parent admission and source mutation guarantees.
