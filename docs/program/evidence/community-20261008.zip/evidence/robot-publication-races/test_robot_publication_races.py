"""Executable security assertions; two currently RED on Linux, isolated paths only."""
import os
from pathlib import Path

from actions.server import _api_robots


def fixture_paths(tmp_path, monkeypatch):
    package = tmp_path / 'package'
    package.mkdir()
    (package / 'robot.yaml').write_text('tasks:\n  Synthetic:\n    command: python -c pass\n')
    (package / 'payload.txt').write_text('synthetic package content')
    robots = tmp_path / 'robots'
    robots.mkdir()
    monkeypatch.setattr(_api_robots, 'ROBOTS_DIR', robots)
    return package, robots


def test_complete_valid_package_control(tmp_path, monkeypatch):
    package, robots = fixture_paths(tmp_path, monkeypatch)
    name, destination = _api_robots._publish_robot_package(package, 'safe', None)
    assert name == 'safe'
    assert destination == robots / 'safe'
    assert (destination / 'payload.txt').read_text() == 'synthetic package content'
    assert list(robots.iterdir()) == [destination]


def test_competing_empty_destination_is_not_replaced(tmp_path, monkeypatch):
    package, robots = fixture_paths(tmp_path, monkeypatch)
    replace = os.replace
    competing_identity = []

    def interleaved_replace(source, destination, *args, **kwargs):
        destination = Path(destination)
        if destination == robots / 'safe' and not competing_identity:
            destination.mkdir()
            competing_identity.append(destination.stat().st_ino)
        return replace(source, destination, *args, **kwargs)

    monkeypatch.setattr(_api_robots.os, 'replace', interleaved_replace)
    _api_robots._publish_robot_package(package, 'safe', None)
    assert (robots / 'safe').stat().st_ino == competing_identity[0], 'Publication replaced a competing destination directory'
    assert list((robots / 'safe').iterdir()) == [], 'Publication replaced existing authority'


def test_root_link_swap_does_not_publish_outside_pinned_root(tmp_path, monkeypatch):
    package, robots = fixture_paths(tmp_path, monkeypatch)
    outside = tmp_path / 'outside'
    outside.mkdir()
    pinned = tmp_path / 'original-robots'
    copytree = _api_robots.shutil.copytree
    swapped = False

    def interleaved_copytree(source, destination, *args, **kwargs):
        nonlocal swapped
        if not swapped:
            swapped = True
            robots.rename(pinned)
            robots.symlink_to(outside, target_is_directory=True)
        return copytree(source, destination, *args, **kwargs)

    monkeypatch.setattr(_api_robots.shutil, 'copytree', interleaved_copytree)
    _api_robots._publish_robot_package(package, 'safe', None)
    assert list(outside.iterdir()) == [], 'Publication escaped through a replaced output root'


def test_failed_copy_does_not_delete_unowned_staging_collision(tmp_path, monkeypatch):
    package, robots = fixture_paths(tmp_path, monkeypatch)
    copytree = _api_robots.shutil.copytree
    foreign = []

    def interleaved_copytree(source, destination, *args, **kwargs):
        destination = Path(destination)
        if not foreign:
            destination.mkdir()
            (destination / 'foreign.txt').write_text('not created by publication')
            foreign.append(destination)
        return copytree(source, destination, *args, **kwargs)

    monkeypatch.setattr(_api_robots.shutil, 'copytree', interleaved_copytree)
    try:
        _api_robots._publish_robot_package(package, 'safe', None)
    except FileExistsError:
        pass
    assert foreign[0].is_dir(), 'Failure cleanup deleted a directory it never created'
    assert (foreign[0] / 'foreign.txt').read_text() == 'not created by publication'
