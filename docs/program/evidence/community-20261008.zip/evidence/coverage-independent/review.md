# Independent coverage gate review

Exact reviewed commit: fc09d0b26a80201587de310e24042787252ae3af. Worktree clean before and after review. Read-only review; worker owns implementation.

Result: no remaining actionable finding in this bounded gate. The initial aggregate denominator weakness and subprocess-report wording are corrected in this exact commit.

## Independent checks

- Prepared RCC/Poetry execution of `developer/tests/test_coverage_gate.py`: 7 PASS.
- Independently reaggregated the actual ordinary measurement reports at `/tmp/luna-cov-verify/packages`: 15,908 covered statements / 29,796 source statements = 53.3897%, above the committed 53.38% floor.
- All 259 expected source files appear; no unexpected files. 35 executable modules with zero covered lines remain in the denominator. Existing coverage defaults exclude 345 source lines; this is an aggregate line gate, not a branch/per-package gate or a ban on future exclusion pragmas.
- Source inventory digest exactly matches committed measured baseline `155ad5d5e5d23938bf1978016614259fd7adb8055297a4a2757f684b766c5bea`.
- The original aggregator accepted an injected covered non-source file and inflated the same real reports from 53.3897% to 98.6514%. Exact successor rejects this with ValueError; per-file counts are now validated and summed only over expected source files, with package totals checked for consistency.
- Full orchestration was replayed against those stored reports: 53.38 floor exits 0; raised 54 floor exits 1 with `coverage below measured floor`. See `replay.py` and `passing-replay` / `raised-floor-replay` receipts. This replay does not rerun the package suites; the worker's actual ordinary gate receipt records five successful test processes.
- All pytest-cov/coverage dependencies are locked in dev groups. Devutils' two coverage versions have disjoint Python-version markers. No coverage dependency is added to runtime wheel requirements by these declarations.
- Workflow runs Doctor -> Bootstrap -> ToolkitTest -> Coverage on Linux, with pinned RCC binary hash, read-only contents permission, triggers for community and the current integration PR target, and report upload after failure. CI runs ordinary measurement, not baseline rewriting.

## Scope and remaining verification

The maintained denominator is the five package `src/**/*.py` trees, not developer/build/test scripts or TypeScript. Persistent backend service tests and Runtime integration tests are explicitly excluded and remain independent gates. Coverage is not complete subprocess, installed-wheel or native distribution proof; subprocess activation depends on pytest-cov/environment propagation. New source changes after integration must pass the ordinary coverage gate again. Hosted execution of the exact final integration commit is not established by this local review.

## Documentation improvement

Canonical file changed by the worker: `docs/BUILD_INSTRUCTIONS.md`.
Durable learning: count only inventoried maintained source summaries; include unimported namespace modules; keep subprocess/wheel coverage claims conditional.
Evidence: independent real-report aggregation, 7 passing focused tests, inflation rejection and orchestration floor replay.
Stale guidance removed: categorical claims that all non-worker subprocesses are unmeasured; blanket trust in aggregate totals.
Remaining uncertainty: hosted exact integration gate, independent service/wheel/native checks, and aggregate-versus-per-package policy remain separate acceptance scopes.
