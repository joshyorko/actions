# Artifact and template documentation successors

Artifact exact `ab8c69a94cac3c029c278fe48e0ab49c82485001`: target-independent lstat rejects symbolic links or reparse attributes without an exists gate, resolving the dangling inner-junction source finding. Independently ran complete artifact suite with explicit candidate source origin:27PASS. Actual Windows alias/junction proof and race-free no-follow operations remain NOT_RUN locally; no new actionable bounded finding.

Template docs exact `28b021c6307c5c993f0ba2859d0da2ae3d9e8c94`: no actionable finding. Community-facing README links replace obsolete product/editor marketing and point at actual existing canonical guides. Quickstart anchor exists. All four inner ZIP README/package.yaml bytes independently match their source files, per-template ZIPs match outer archive members, metadata hash matches SHA256 abca22b306298017c5137dad1a286d1519cc249dfd4d44271acb2e4090bdb076. Compared every embedded entry against parent: only README.md bytes changed in three templates; fourth unchanged. Candidate Core1.0.2 and WorkItems0.4.4 pins preserved. No license/legal/attribution files modified. This is a bounded docs/generated-artifact correction, not whole #125 cleanup acceptance.

Documentation improvement:
- Canonical file changed or proposed: refreshed templates/README.md and three generated-project READMEs; docs/skills/work-items.md filesystem guidance.
- Durable learning captured: community product docs must be regenerated into shipped template ZIPs; metadata and every inner archive member must match source while package pins/legal files stay intact. Reparse detection uses target-independent lstat.
- Evidence: artifact27PASS; complete archive member comparison, source equality and hash checks above.
- Stale or ambiguous guidance removed: obsolete Sema product/editor marketing links and exists-based dangling-link detection.
- Remaining uncertainty: actual Windows artifact checks, full #125 surface inventory and native package release gates.
