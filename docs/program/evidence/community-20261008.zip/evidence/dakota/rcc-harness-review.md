# Dakota RCC harness review — 8ce8bb07498d0c15ae27fe55f1e30bc21bf0cbb5

Read-only review by cloud Luna coverage lane. No files changed or processes started. No retained live passing receipt was available; this is code review, not execution acceptance.

The harness uses source Runtime, locally built Core1.0.2/Helper1.0.2 wheels, a synthetic package, actual loopback RCC cache provider, authenticated HTTP and SQLite passed-Run/receipt assertions. This is a useful local vertical design, not a native Runtime or distributed proof.

Open findings:
1. Outer pytest timeout1200s can kill the harness before nested600+900+900s limits and skip finally, orphaning descendants. Use a coherent total deadline and owned process-tree cleanup, with a timeout regression.
2. Candidate wheel builder falls back to arbitrary PATH Poetry despite pinned-toolchain claim. Require/verify RCC Poetry.
3. Provider/Runtime/actions inherit os.environ; storage isolation does not isolate credentials. Apply an appropriate environment allowlist and prove it.
4. Provider startup terminate/wait has no kill fallback when wait times out; use bounded owned cleanup consistently.
5. Retain source SHA, candidate wheel hashes and live receipt beyond temporary cleanup. Do not infer PASS from help/discoverability tests.

Documentation proposal: canonical BUILD_INSTRUCTIONS should describe explicit RCC/Poetry inputs, candidate-wheel/source scope, actual command, bounded cleanup, and receipt limits once findings are resolved.
