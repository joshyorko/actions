# Native gate and URL successor review

Exact head `119b4f118bddb999ab1fc31b6edc5dd7fca36209`. Read-only source review; complete Robot39PASS independently, including request-target preservation and TCP/TLS instrumentation. The prior signed semicolon URL defect is fixed using urlsplit with exact encoded query/path regression. Prior admitted-IP/TLS identity and Win32 source-policy repairs remain intact.

Native gate assessment: genuine Chromium sign-in, HttpOnly/Strict named-cookie assertions, no key in localStorage, authenticated WebSocket echo, create/list/detail, logout protected403, no page errors or external requests, restart persistence, missing404 and corruption503 are all meaningful. Negative browser control deliberately injects403 and requires exact failure phase/status; positive flow does not mock API responses. Workflow covers Linux/Windows/macOS builds and runs both frozen and wrapper products before uploading the binary. This is technical validation, not publication permission.

Owned cleanup finding/proof gap: Windows owned_process finally only invokes taskkill /PID /T while the leader is still running. If leader has exited but an owned Runtime/Chromium descendant remains, tree cleanup is skipped. POSIX explicitly handles this by final process-group kill. Use a Windows Job Object with kill-on-close or another exact owned-descendant mechanism, with a leader-exits-first regression; do not use process-name sweeps. This prevents claiming unconditional Windows cleanup from the current harness.

Provenance limits: source SHA is a required caller assertion rather than embedded artifact attestation. CI binds it to github.sha immediately after build, but local callers must pass the actual build SHA. Frozen SHA covers the executable alone, not its adjacent native directory dependencies. Binary hash immutability is checked after acceptance. Temporary logs/keys are not uploaded; bounded JSON receipts avoid raw errors and bodies. Receipt of old023 binaries must remain old023 evidence, even when run with the newer harness.

NOT_RUN by this reviewer: full native119 gate, full final RCC suites, cross-platform native executions, live network/TLS acquisition, native Core worker execution/Work Item state transitions, concurrent no-follow publication races. #151/#152 whole acceptance remains unfinished until retained cells are established. No merge/tag/publication authorization follows from passing source tests.

Documentation improvement:
- Canonical file changed or proposed: docs/skills/repository-operations.md native verification guidance.
- Durable learning captured: Proposed addition: "Native receipts must distinguish build-source SHA from harness SHA and executable-only hashes from complete frozen-directory identity. Owned-process cleanup must cover descendants whose leader exits first on every supported OS; Windows process-group creation alone is not a kill-on-close job. Keep Worker state transitions, live TLS and no-follow race acceptance separate from browser/storage smoke proof."
- Evidence: Robot39PASS; exact harness/workflow inspection; Windows poll guard and POSIX contrasting final cleanup; credential-free receipt fields and browser assertions.
- Stale or ambiguous guidance removed: treating native browser/storage smoke as complete worker security acceptance or leader termination as complete cross-platform tree cleanup.
- Remaining uncertainty: Windows cleanup repair, current native/full-gate results and retained security cells above.
