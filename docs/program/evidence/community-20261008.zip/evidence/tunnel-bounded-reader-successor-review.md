# Bounded reader successor review

Exact PR225 source `c789123802bf83770d283cb6ca04bae7c4fbfae2`. Independent complete provider/lifecycle suites30PASS, including actual newline-free local child cancellation, reaping and reader-exit assertions. Fixed4096byte binary read1 plus64entry queue bounds queued payload256KiB and pending tail512bytes; arbitrary output is not logged. Timeout/cancellation runs stop/reap off-loop. This closes prior unbounded-line allocation and observed empty-queue blocking.

Two remaining actionable correctness findings:
1. pending overlap is shared between stdout and stderr. Independent real BytesIO reader probe with stdout `https://synthetic` and stderr `-joined.trycloudflare.com` returned `https://synthetic-joined.trycloudflare.com`, an endpoint neither stream emitted. Maintain a tail per stream and test split URL within one stream succeeds while cross-stream assembly fails.
2. Main consumer only yields on queue.Empty. A continuously ready queue processes/searches chunks without await until timeout, delaying cancellation/other tasks. Independent saturated-queue control plus actual owned quiet child observed a0.01second heartbeat delayed0.16seconds under a0.15second deadline; process cleanup still succeeded. Yield each bounded chunk or finite batch and add deterministic saturated-queue responsiveness proof; real flood test's naturally empty moments are insufficient guarantee.

Reader joins are bounded1second but no is_alive check fails stop if a reader survives; retain this as an unproved cleanup cell, particularly inherited pipe writers/native behavior. Public edge auth, configured URL identity, actual token/provider compatibility, native/source/wheel matrix, state races and dual legacy controller remain #214 blockers. No integration/release acceptance.

Documentation improvement:
- Canonical file changed or proposed: docs/skills/repository-operations.md bounded provider reader guidance.
- Durable learning captured: Proposed addition: "Stream overlap buffers are per source; combining stdout/stderr can synthesize an endpoint. Async consumers must yield under sustained input, not only when queues become empty. Prove byte budgets and saturated-input cancellation deterministically in addition to a real child flood/reap control."
- Evidence: independent30PASS; cross-stream endpoint probe; saturated queue heartbeat/reap probe.
- Stale or ambiguous guidance removed: occasional empty-queue responsiveness as complete cancellation proof or shared output tail as authentic single-stream URL.
- Remaining uncertainty: successor fixes, join-timeout failure policy and actual provider/native/edge acceptance.
