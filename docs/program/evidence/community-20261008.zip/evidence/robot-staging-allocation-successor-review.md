# Initial Robot staging allocation repair

Exact candidate `096292b302d063c2ef27312f2a17eda4f1e5ac86` in browser-auth. No actionable finding in the narrowly scoped initial-collision repair.

Independent complete Robot API suite40PASS with explicit candidate source path. New real os.mkdir collision regression creates a foreign staging directory/sentinel before exclusive allocation, expects FileExistsError and verifies sentinel remains. Ownership flag is set only after successful mkdir; failed allocation never authorizes cleanup. Existing interrupted partial-copy regression still proves owned partial staging cleaned and no final authority published; its mock now accepts the deliberate prior allocation instead of falsely requiring a missing directory. Copytree into the owned allocation uses dirs_exist_ok without changing archive admission/HTTP/TLS policy.

This is pathname ownership at initial allocation, not lifetime directory identity. Later staging replacement, root link/rename replacement and final-destination no-replace races remain unresolved. The flag does not prove the directory currently at that path is still the allocated object. mkdir0700 does not establish final root permissions after copytree copies source metadata; do not advertise complete private snapshot/parent security from this patch. No full #151/#148 acceptance, native race proof or release approval.

Documentation improvement:
- Canonical file changed or proposed: docs/skills/repository-operations.md Robot publication guidance.
- Durable learning captured: Proposed addition: "Cleanup authority starts only after exclusive staging allocation succeeds. A failed initial name collision must preserve the competing entry; ownership flags alone do not establish identity after later replacement. Retain separate root-replacement and atomic no-replace publication gates."
- Evidence: complete40PASS; actual mkdir collision/sentinel and existing partial-copy regression; exact allocation flag/copy/finally diff.
- Stale or ambiguous guidance removed: random staging name existence as cleanup authority and initial allocation fix as complete race-free publication.
- Remaining uncertainty: lifetime root/staging identity, final no-replace operation and supported native platform proof.
