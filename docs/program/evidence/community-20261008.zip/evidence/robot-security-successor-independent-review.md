# Robot security successor review

Exact head `c5ec12867f8d1cf4dea737d1cba33a6a83ea6589`. Read-only source review and existing-environment tests.

Verdict: the two preceding security findings are repaired in the bounded source/transport slice. One URL request-target preservation regression remains actionable before approval of this slice.

Finding: `_pinned_download_request` uses urlparse but serializes with urlunsplit, omitting parsed.params. Independent probe `https://downloads.example.test/robot.zip;signature=synthetic?version=1` becomes `https://93.184.216.34/robot.zip?version=1`. Valid semicolon path signatures/matrix parameters are silently lost, breaking supported URL workflows. Use path-preserving urlsplit or deliberately retain the params and add exact request-target regression.

PASS: independently ran complete Robot suite,38PASS, including the real HTTPX2/httpcore2 TCP/TLS-boundary instrumentation. It verifies the admitted literal IP reaches connect_tcp, original hostname reaches start_tls, CERT_REQUIRED and check_hostname remain active, and malicious HTTPS_PROXY does not route this acquisition. No actual socket/TLS network traffic was claimed. Fresh clients per redirect prevent IP-keyed pool reuse across original TLS identities and cookie carryover. Entire DNS answer sets are validated, no insecure fallback is added, and redirected destinations repeat admission.

PASS source review: archive component admission rejects ADS colons, invalid Win32 characters, trailing-dot/space aliases, reserved device extension forms and documented COM/LPT superscript aliases. This closes the reproduced source-policy gap on all OSes; actual native Windows/macOS extraction is still NOT_RUN.

NOT_RUN: live TLS/redirect acquisition against controlled DNS infrastructure, native path semantics, concurrent output-directory rename/symlink races, common #148 staging integration, whole #151/#152 acceptance, final full RCC candidate gates and publication. Existing absence of directory-handle no-follow publication proof is retained.

Documentation improvement:
- Canonical file changed or proposed: docs/skills/repository-operations.md, new Robot source connection and portable archive identity section.
- Durable learning captured: Proposed exact addition: "Pinned-address URL rewriting must preserve the complete original path and query request target, including semicolon path parameters and encoded signature bytes; validate this independently of Host/SNI identity."
- Evidence: independent lost-semicolon probe; complete Robot38PASS with actual instrumented transport/TLS boundary; exact source review.
- Stale or ambiguous guidance removed: treating preserved hostname identity as sufficient proof that URL rewriting preserves supported downloads.
- Remaining uncertainty: successor request-target regression, real network/native/no-follow/platform cells remain required and distinct.
