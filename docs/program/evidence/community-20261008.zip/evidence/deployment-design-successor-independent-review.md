# Deployment design successor review

Exact proposed head `e4e54d31647b7d44cdd7c07d6006596186db8317`.

No actionable finding in bounded successor. Workspace-global idempotency lookup agrees with request PK. Collection create digest explicitly uses null target and complete canonical body before server-generated identity allocation; replay returns the originally generated IDs only after current reauthorization. Other operations bind target, operation, parent precondition and payload; cross-Deployment reuse conflicts without disclosure/mutation. Added design tests cover authorization loss and two-Deployment reuse. Prior contradictory lookup scope is resolved.

Independently ran the scratch SQLite probe using the already prepared Runtime package interpreter:PASS, linked SQLite3.53.4. It exercises forward/cyclic graph DDL, representative same-owner/cross-scope FK negatives, four current-pointer tuples, binding/grant references, workspace-key replay/conflict and a generic transactional DDL rollback. It is scratch proposed SQL, not production migration/helper code. It leaves d2/d3 null-pointer owner fixtures at commit, so it does not prove the proposed non-null-at-commit repository invariant. Replay helper has no authorization implementation; triggers, concurrent CAS, publication ancestry semantics, actual failed-bootstrap rollback, fresh/upgrade parity and PostgreSQL are NOT_RUN.

Documentation improvement:
- Canonical file changed or proposed: docs/design/deployment-revisions-draft.md corrected publication/key-scope section; docs/skills/repository-operations.md database verification guidance.
- Durable learning captured: Proposed guide sentence: "Scratch FK-graph DDL and generic rollback tests are separate from complete bootstrap pointer invariants, immutable triggers, replay authorization, concurrent CAS and backend migration parity; name every unexercised invariant in the receipt."
- Evidence: exact key-scope successor diff; independent SQLite scratch PASS and source fixture/replay inspection.
- Stale or ambiguous guidance removed: deployment-local lookup under Workspace-global SQL key; treating scratch FK success as complete schema/repository implementation.
- Remaining uncertainty: all actual implementation and PostgreSQL gates; this is proposed design checkpoint review, not #129 acceptance.
