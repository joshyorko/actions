# Native Job ownership successor review

Exact integration head `7c45029b46d13b037d7df11be7f79d4cdb956626`, including Astra `757e8ed1ccd3db343b4489496c1faab3b638db0d`. Read-only review, no production edits or publication.

Verdict: no actionable finding in the bounded harness successor. The prior Windows source ownership gap is repaired structurally; actual Windows runtime proof remains NOT_RUN locally.

PASS: independently ran scripts/test_native_process_ownership.py with the existing Runtime package interpreter:3PASS1WindowsSKIP. Portable tests prove an exact unbuffered three-byte GO newline gate preserves following browser JSON stdin bytes, and invalid/incomplete gates never launch the real child. Startup diagnostic tests retain bounded class/module identifiers without API key, Authorization/Cookie message text or private paths.

Source review: Windows Job handle is non-inheritable and configured KILL_ON_JOB_CLOSE. A Python wrapper blocks on the gate before spawning any actual command; parent assigns the wrapper to the Job before releasing GO. Children inherit Job ownership without breakaway flags. Failure to create/configure/open/assign/close Job raises an explicit bounded failure, with no unowned fallback. Job closes in finally even when the wrapper/leader exited, followed by bounded process wait/kill and stdin cleanup. Binary and browser commands remain argument lists without shell. Browser JSON credential goes through stdin; diagnostics strip the synthetic key before extracting identifiers. Native process logs are checked for that key before removal. --api-key=value removes value-token parsing ambiguity but does not explain the preceding Windows startup failure.

The Windows leader-exits-first test holds an exact descendant process handle, verifies it is initially alive, then checks Job-close termination and cleans that exact process on failed proof. This is meaningful hosted Windows proof when run, not satisfied by the local skip. Existing source SHA/build identity limitations remain: source SHA is caller-supplied build identity and executable digest does not identify every frozen-directory dependency.

NOT_RUN: actual Windows Job test and new Windows native gate locally. Earlier Windows119 native_startup_exit remains a real unattributed failure; successful version/build checks do not waive it. Linux native receipt and full RCC568PASS10SKIP are parent-reported evidence against their stated source, not independently rerun here. Native worker state transitions, live TLS acquisition and no-follow races remain separate #151/#152 acceptance cells.

Documentation improvement:
- Canonical file changed or proposed: docs/skills/work-items.md native acceptance section, existing successor guidance.
- Durable learning captured: Windows ownership must assign a gated launcher before child creation and close a non-inherited kill-on-close Job even after leader exit. Preserve stdin byte boundaries and retain bounded diagnostics rather than raw logs.
- Evidence: portable3PASS1WindowsSKIP; exact WinAPI signature/structure, assignment/gate/finally and diagnostic source inspection; actual Windows-specific held-handle test is retained for hosted execution.
- Stale or ambiguous guidance removed: taskkill guarded only by leader liveness as sufficient descendant cleanup, and speculative attribution of startup failure to key parsing.
- Remaining uncertainty: hosted Windows Job/native execution and original startup cause; full product/platform/security graph acceptance is not granted by this receipt.
