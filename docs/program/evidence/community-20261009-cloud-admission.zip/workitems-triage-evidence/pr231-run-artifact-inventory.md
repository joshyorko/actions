# PR231 Linux native artifact inventory (read-only)

Inventory date: 2026-10-09. No artifact was downloaded.

## Run / source identity

- Actions run `37953759501` is complete/successful, workflow `Action Server Build (Unauthenticated)`, event `pull_request`, branch `feature/dakota-workitems-acceptance-20261008`, API `headSha=49becb96767d4fc225fb9cb79162db9a9d1dafd8` (PR231 head).
- Linux job `113898921838`, “Build Action Server binary without credentials (ubuntu-22.04),” completed successfully.
- The job log shows checkout did not build the branch SHA directly: `actions/checkout@v3` fetched `refs/remotes/pull/231/merge` at `873237dfd9c3d59d10b2765c8c77cfa85f59b095` and checked it out. The merge commit parents are base `376ed4c15c76ccf1b5e3b70985e681946bffd249` and PR head `49becb96767d4fc225fb9cb79162db9a9d1dafd8`.
- The same job log shows both native receipt commands received `--source-sha 873237dfd9c3d59d10b2765c8c77cfa85f59b095`. This is source association through GitHub run/job logs and caller-provided receipt input; the upload workflow has no binary build manifest or attestation. The commit tree is fetchable, but the binary-to-source association relies on Actions execution record rather than an embedded build manifest.

## Artifact metadata from GitHub REST

All listed artifacts came from run `37953759501`, report `workflow_run.head_sha=49becb...`, unexpired at inventory time, retention ends 2026-10-16:

| Artifact | ID | Size | Uploaded paths in workflow |
|---|---:|---:|---|
| `action-server-unauthenticated-ubuntu-22.04` | `11627207864` | 77,642,504 bytes | `.github/workflows/frontend-build-unauthenticated.yml` uploads only `action_server/dist/final/` |
| `native-acceptance-ubuntu-22.04-873237dfd9c3d59d10b2765c8c77cfa85f59b095` | `11626663884` | 1,599 bytes | `action_server/output/native-acceptance.json` and `native-history.json` |

The combined download would be about 77.65 MB, under the 500 MB limit. The workflow's `dist/final/` path is the Go-wrapper output directory; it does not upload `dist/action-server/`, the frozen PyInstaller directory required for the two-case Dakota Work Items runner. The browser receipt artifact is evidence only and does not retain executable bytes. Thus this run does not retain both Linux binaries needed to invoke the unchanged current dual-runtime runner. No Linux artifact is downloaded until the coordinator sets the next scope.

The native job success proves browser/storage/history behavior for both runtimes during the hosted job, but does not provide both binaries for a subsequent local synthetic consumer lifecycle. No claim is made about the archive's internal member list because it has not been downloaded/inspected.

## Canonical documentation proposal

Target: `docs/skills/work-items.md`, under “Dakota packaged-worker gate”. Current wording correctly says retained Linux artifacts do not establish current-source builds. A further useful durable boundary, pending integration approval:

> The unauthenticated native workflow uploads `action_server/dist/final/` and separate native receipts. It does not upload `action_server/dist/action-server/`, so its retained Linux artifact alone cannot replay the Dakota gate that requires both frozen and Go-wrapper executables. The Actions checkout/receipt source SHA identifies the tested merge checkout; it is not a binary build manifest.

Evidence: workflow at PR head `49becb...` (`frontend-build-unauthenticated.yml`) upload step specifies `action_server/dist/final/`; job logs identify checkout merge `873237...` and pass that SHA to native receipt scripts; REST artifact metadata reports 77,642,504-byte Linux binary and 1,599-byte receipt. Uncertainty: archive members are not verified because no artifact was downloaded; document that workflow path behavior only. The receipt artifact's actual JSON content is also not inspected yet.

Documentation improvement receipt:
- Canonical file changed or proposed: Proposed exact delta to `docs/skills/work-items.md`; no checkout or shared governance file changed.
- Durable learning captured: Native workflow's receipt is not a replayable dual-runtime binary package; only `dist/final` is retained, and source SHA associates to GitHub's merge checkout rather than proving an embedded build manifest.
- Evidence: workflow definition at exact PR head, GitHub job checkout/build command logs, merge commit parents, and REST artifact metadata.
- Stale or ambiguous guidance removed: None; existing guide already limits retained artifact/current-source claims.
- Remaining uncertainty: Actual zip contents/hashes and receipt JSON remain unread pending coordinator scope; no current-source Work Items consumer run was made.

## Download attempt and follow-up

The authorized GitHub REST artifact download request returned the signed Azure blob redirect, but the workspace network proxy rejected the blob-host tunnel with HTTP 403. No ZIP bytes were received or saved, no archive members were inspected, and no extraction was attempted. The download directory remains empty. I did not use alternate domains or caches.

A local filesystem search found unrelated Action Server outputs in `workitems/action_server/dist/action-server` and `actions-cloud/validation/action_server/dist/{action-server,final}`. They have no checked artifact-run identity or retained manifest tying them to Linux job `113898921838`, so they are not substitutes for the run's bytes and were not executed. The exact GitHub artifact byte hashes and receipt JSON remain unknown. The current run cannot support an honest local Go-only or frozen+Go replay from verified downloaded bytes.

## Minimal workflow retention change implemented on separate branch

The existing Go-wrapper upload name and path are kept. A second artifact uploads `dist/action-server/` plus a generated `output/native-artifact-manifest.json`. The generator checks `git rev-parse HEAD` against the workflow SHA and records actual Python/Go versions, OS/architecture, build invocation, relative executable paths and measured executable SHA-256 values. Its download map identifies the existing Go artifact name and the new frozen/manifest artifact paths. It explicitly does not claim a candidate Core wheel, which this workflow does not build. This change is on separate branch `feature/workitems-native-artifact-manifest-20261009` based on `4626cc56bdde0cee92010ae1b985e5d385e4c0d2`; it is not a claim about run `37953759501` or PR231. Focused tests and canonical docs are in progress there.

Documentation improvement receipt (current inventory lane):
- Canonical file changed or proposed: `docs/skills/work-items.md` was changed in the separate artifact-retention branch; it is not integrated into PR231.
- Durable learning captured: The upload omission prevents later frozen-runtime replay; receipt-only upload is not an executable artifact; a manifest can bind checkout SHA to measured executable hashes while leaving Core-wheel provenance explicitly absent.
- Evidence: workflow source, GitHub REST artifact sizes, run/job checkout logs and source arguments, proxy rejection of the blob host, empty download directory, and unbound local-output inventory.
- Stale or ambiguous guidance removed: The docs proposal was replaced on the separate branch with the actual implemented workflow contract, while preserving the limit that current workflow code does not imply a Core wheel.
- Remaining uncertainty: Actual ZIP members, downloaded executable hashes, and native receipt JSON for run `37953759501`; no replay is admissible from this environment. The proposed workflow change has not run in CI yet.

Retention implementation completed: commit `c04a164316eee158797373b115e8fe91e85ed67c`, pushed branch `feature/workitems-native-artifact-manifest-20261009`, draft PR #237 targeting `integration/community-release-20261008` (https://github.com/joshyorko/actions/pull/237). Worktree is clean at the exact pushed head. Validation: manifest tests 2 passed; process-ownership tests 22 passed, 3 Windows-only skipped; Ruff check/format, Python compilation, workflow YAML parse, and `git diff --check` passed. No native build or external acceptance run was made.

## PR237 review follow-up and pinned validation

Reviewer receipt `artifactreviewreceipt-c04a1643.json` identified an actual Windows test-fixture mismatch: production chooses `.exe` on Windows while the success fixture previously created extensionless files. The fixture now loops over Linux/no-suffix and Windows/`.exe` variants, mocking the host platform selection so both path behaviors run in the current Linux worker. It verifies both artifact archive paths and measured hashes. This is a meaningful platform-contract test, but it is not a native Windows run; the workflow matrix still needs a fresh Windows/macOS/Linux CI result after the fix.

The manifest/docs now say source identity is the `git rev-parse HEAD` equality check only, not a clean-tree/source-byte attestation. Hashes are for bytes read from named paths; `Path.is_file` and ordinary reads follow symlinks/reparse points, so the manifest does not prove filesystem object identity or path containment. The Core wheel remains outside this build's provenance.

Workflow ownership check: `.github/workflows/frontend-build-unauthenticated.yml` is absent from `.github/workflows/_gen_workflows.py`'s `TARGETS` list and the generator contains no reference to its path. It is hand-maintained; running `_gen_workflows.py` would not overwrite it. No generator was run.

Pinned validation in the artifact worktree, using `/workspace/actions-cloud/activate.sh` and RCC 18.19.3:

- `rcc run -r developer/toolkit.yaml --dev -t Doctor` — exit 0; Doctor reported Python 3.12.15, Poetry 2.1.1, Invoke 2.2.0, Node 20.19.3, Go 1.23.6.
- `rcc run -r developer/toolkit.yaml --dev -t Bootstrap` — exit 0; prepared package Poetry environments from the repository's lockfiles.
- `rcc run -r developer/toolkit.yaml --dev -t ToolkitTest` — exit 0; Ruff passed and all 33 toolkit tests passed.
- `rcc task script -r developer/toolkit.yaml -- python -c 'import toolkit; toolkit.poetry("action_server", "run", "python", "-m", "unittest", "discover", "-s", "scripts", "-p", "test_native*.py", "-v"); toolkit.poetry("action_server", "run", "ruff", "check", "scripts/write_native_artifact_manifest.py", "scripts/test_native_artifact_manifest.py"); toolkit.poetry("action_server", "run", "ruff", "format", "--check", "scripts/write_native_artifact_manifest.py", "scripts/test_native_artifact_manifest.py")'` — exit 0; all 27 relevant native script tests passed, 3 existing Windows-only process tests skipped on Linux; Ruff check and format check passed. The manifest test covers both suffix variants via mocked platform selection.

No full Action Server runtime package gate was repeated: the change adds an artifact manifest script/workflow steps/docs and does not alter runtime package behavior. Actual hosted Windows/macOS matrix results are pending; no local native build or external service test was run. RCC bootstrap owns package `.venv` directories in this worktree; no RCC/test processes remain active.

Documentation improvement receipt (review follow-up):
- Canonical file changed: `docs/skills/work-items.md` in the PR237 follow-up commit.
- Durable learning captured: this workflow is hand-maintained; HEAD equality is not a clean-source attestation; path reads follow links and hash bytes without filesystem identity proof.
- Evidence: generator `TARGETS`, workflow/helper code, reviewer receipt, and pinned RCC/Poetry results above.
- Stale or ambiguous guidance removed: provenance language now describes checkout identity and measured path bytes with explicit limits.
- Remaining uncertainty: real Windows and macOS CI acceptance is pending after the fixture fix; symlink/reparse containment is not claimed or implemented.

Hosted CI follow-up:
- The first PR237 native workflow run at `c04a164316eee158797373b115e8fe91e85ed67c` failed only in the Windows prebuild manifest test, matching the fixture issue. Run `37957251426`, job `113898921838`; the log reports `FileNotFoundError: frozen executable missing` for the extensionless fixture when the writer selected `.exe`.
- Cross-platform fixture and provenance-scope corrections are pushed at `9d98be6f99fae22289b29ae74f4d6a5c66c2f3d1`; independent expected-byte hash assertions are pushed at current head `8013d17256f4b4c20cc4d36141c08bca2c964354`.
- The three-platform native workflow at `9d98be6f99fae22289b29ae74f4d6a5c66c2f3d1` was still in progress at last inspection (`37957800607`). After the final hash-assertion-only commit, GitHub queued a current-head native workflow run `37957938458` for `8013d17256f4b4c20cc4d36141c08bca2c964354`; its Linux/macOS/Windows results are pending.
- Independent hash assertions now compare against `hashlib.sha256` over known fixture bytes, not the writer's own digest helper. Pinned RCC/Poetry script tests and targeted Ruff checks passed after this change (27 passed, 3 existing Windows-only skips). No actual Windows run is claimed yet.

Current revision after reviewer correction: `8013d17256f4b4c20cc4d36141c08bca2c964354`, pushed and clean. The success fixture's hash assertions compare to independent SHA-256 values from fixture bytes. Final focused RCC/Poetry checks remain 27 passed / 3 existing Windows-only skips, with targeted Ruff check and format pass. Current-head native matrix run `37957938458` is in progress: manifest contract steps passed on Linux and macOS, and Linux manifest-generation step passed; Windows had not yet reached the manifest test at the last check. This partial progress is not whole-matrix or #208 acceptance. Parent is monitoring the combined status.
