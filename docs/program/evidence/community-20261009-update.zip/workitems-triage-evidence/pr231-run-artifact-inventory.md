# PR231 Linux native artifact inventory (read-only)

Inventory date: 2026-10-09. No artifact was downloaded.

## Run / source identity

- Actions run `37953759501` is complete/successful, workflow `Action Server Build (Unauthenticated)`, event `pull_request`, branch `feature/dakota-workitems-acceptance-20261008`, API `headSha=49becb96767d4fc225fb9cb79162db9a9d1dafd8` (PR231 head).
- Linux job `113898921838`, “Build Action Server binary without credentials (ubuntu-22.04),” completed successfully.
- The job log shows checkout did not build the branch SHA directly: `actions/checkout@v3` fetched `refs/remotes/pull/231/merge` at `873237dfd9c3d59d10b2765c8c77cfa85f59b095` and checked it out. The merge commit parents are base `376ed4c15c76ccf1b5e3b70985e681946bffd249` and PR head `49becb96767d4fc225fb9cb79162db9a9d1dafd8`.
- The same job log shows both native receipt commands received `--source-sha 873237dfd9c3d59d10b2765c8c77cfa85f59b095`. This is source association through GitHub run/job logs and caller-provided receipt input; the upload workflow has no binary build manifest or attestation. The commit tree is fetchable, but the binary-to-source association relies on Actions execution record rather than an embedded build manifest.

## Artifact metadata from GitHub REST

All listed artifacts came from run `37953759501`, report `workflow_run.head_sha=49becb...`, unexpired at inventory time, retention ends 2026-10-16:

| Artifact | ID | Size | Uploaded paths in workflow |
|---|---:|---:|---|
| `action-server-unauthenticated-ubuntu-22.04` | `11627207864` | 77,642,504 bytes | `.github/workflows/frontend-build-unauthenticated.yml` uploads only `action_server/dist/final/` |
| `native-acceptance-ubuntu-22.04-873237dfd9c3d59d10b2765c8c77cfa85f59b095` | `11626663884` | 1,599 bytes | `action_server/output/native-acceptance.json` and `native-history.json` |

The combined download would be about 77.65 MB, under the 500 MB limit. The workflow's `dist/final/` path is the Go-wrapper output directory; it does not upload `dist/action-server/`, the frozen PyInstaller directory required for the two-case Dakota Work Items runner. The browser receipt artifact is evidence only and does not retain executable bytes. Thus this run does not retain both Linux binaries needed to invoke the unchanged current dual-runtime runner. No Linux artifact is downloaded until the coordinator sets the next scope.

The native job success proves browser/storage/history behavior for both runtimes during the hosted job, but does not provide both binaries for a subsequent local synthetic consumer lifecycle. No claim is made about the archive's internal member list because it has not been downloaded/inspected.

## Canonical documentation proposal

Target: `docs/skills/work-items.md`, under “Dakota packaged-worker gate”. Current wording correctly says retained Linux artifacts do not establish current-source builds. A further useful durable boundary, pending integration approval:

> The unauthenticated native workflow uploads `action_server/dist/final/` and separate native receipts. It does not upload `action_server/dist/action-server/`, so its retained Linux artifact alone cannot replay the Dakota gate that requires both frozen and Go-wrapper executables. The Actions checkout/receipt source SHA identifies the tested merge checkout; it is not a binary build manifest.

Evidence: workflow at PR head `49becb...` (`frontend-build-unauthenticated.yml`) upload step specifies `action_server/dist/final/`; job logs identify checkout merge `873237...` and pass that SHA to native receipt scripts; REST artifact metadata reports 77,642,504-byte Linux binary and 1,599-byte receipt. Uncertainty: archive members are not verified because no artifact was downloaded; document that workflow path behavior only. The receipt artifact's actual JSON content is also not inspected yet.

Documentation improvement receipt:
- Canonical file changed or proposed: Proposed exact delta to `docs/skills/work-items.md`; no checkout or shared governance file changed.
- Durable learning captured: Native workflow's receipt is not a replayable dual-runtime binary package; only `dist/final` is retained, and source SHA associates to GitHub's merge checkout rather than proving an embedded build manifest.
- Evidence: workflow definition at exact PR head, GitHub job checkout/build command logs, merge commit parents, and REST artifact metadata.
- Stale or ambiguous guidance removed: None; existing guide already limits retained artifact/current-source claims.
- Remaining uncertainty: Actual zip contents/hashes and receipt JSON remain unread pending coordinator scope; no current-source Work Items consumer run was made.

## Download attempt and follow-up

The authorized GitHub REST artifact download request returned the signed Azure blob redirect, but the workspace network proxy rejected the blob-host tunnel with HTTP 403. No ZIP bytes were received or saved, no archive members were inspected, and no extraction was attempted. The download directory remains empty. I did not use alternate domains or caches.

A local filesystem search found unrelated Action Server outputs in `workitems/action_server/dist/action-server` and `actions-cloud/validation/action_server/dist/{action-server,final}`. They have no checked artifact-run identity or retained manifest tying them to Linux job `113898921838`, so they are not substitutes for the run's bytes and were not executed. The exact GitHub artifact byte hashes and receipt JSON remain unknown. The current run cannot support an honest local Go-only or frozen+Go replay from verified downloaded bytes.

## Minimal workflow retention change implemented on separate branch

The existing Go-wrapper upload name and path are kept. A second artifact uploads `dist/action-server/` plus a generated `output/native-artifact-manifest.json`. The generator checks `git rev-parse HEAD` against the workflow SHA and records actual Python/Go versions, OS/architecture, build invocation, relative executable paths and measured executable SHA-256 values. Its download map identifies the existing Go artifact name and the new frozen/manifest artifact paths. It explicitly does not claim a candidate Core wheel, which this workflow does not build. This change is on separate branch `feature/workitems-native-artifact-manifest-20261009` based on `4626cc56bdde0cee92010ae1b985e5d385e4c0d2`; it is not a claim about run `37953759501` or PR231. Focused tests and canonical docs are in progress there.

Documentation improvement receipt (current inventory lane):
- Canonical file changed or proposed: `docs/skills/work-items.md` was changed in the separate artifact-retention branch; it is not integrated into PR231.
- Durable learning captured: The upload omission prevents later frozen-runtime replay; receipt-only upload is not an executable artifact; a manifest can bind checkout SHA to measured executable hashes while leaving Core-wheel provenance explicitly absent.
- Evidence: workflow source, GitHub REST artifact sizes, run/job checkout logs and source arguments, proxy rejection of the blob host, empty download directory, and unbound local-output inventory.
- Stale or ambiguous guidance removed: The docs proposal was replaced on the separate branch with the actual implemented workflow contract, while preserving the limit that current workflow code does not imply a Core wheel.
- Remaining uncertainty: Actual ZIP members, downloaded executable hashes, and native receipt JSON for run `37953759501`; no replay is admissible from this environment. The proposed workflow change has not run in CI yet.
