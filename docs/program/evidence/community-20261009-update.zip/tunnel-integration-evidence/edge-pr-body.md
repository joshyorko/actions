## Behavior

When `action-server start --expose` runs with an API key, it now verifies the public Runtime identity, confirms that an unauthenticated MCP initialize is rejected, and validates an authenticated MCP `initialize` response before printing the public URL. The probe makes no Action call. It rejects malformed/non-HTTPS URLs, disables redirects, verifies TLS, and uses one total eight-second deadline.

The MCP SDK uses DNS-rebinding protection with loopback-only defaults. The live MCP app now receives the exact settings object that owns a temporary, exact tunnel host/origin allowance. The allowance preserves loopback and pre-existing entries, is ref-counted, and is revoked after a failed probe or when the owned `TunnelManager` stops. The separate persisted `action-server expose start/status` lifecycle is unchanged and does not become ready from this check.

The branch also includes the tunnel checkpoint's exact directory-publication authorization and Windows workflow steps. This remains a bounded legacy exposure slice; it does not claim full #214 acceptance.

## Validation

- RCC v18.19.3 focused Action Server tests: 111 passed.
- Configured portable Runtime suite (`invoke test-not-integration`): 628 passed, 10 skipped.
- Configured lint and typecheck passed; mypy checked 287 source files.
- Local synthetic ASGI tests exercised unrelated-host and post-revocation 421 responses, missing-auth 403, valid SDK initialize, identity matching, and temporary scope cleanup.

Live public tunnel/provider/TLS checks and native Windows/macOS CI were not run here. Their result remains NOT_RUN.
