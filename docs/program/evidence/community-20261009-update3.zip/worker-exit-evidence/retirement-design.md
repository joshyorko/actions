# #134 idle/completed worker retirement design receipt

Review base: `/workspace/work/community-resume/convergence` at `ea08faf39e107113ae50a529770ce1ca1a422d05`. The full #134 acceptance contract requires old-generation children to drain/reap before the old RCC lease is released; active cancellation remains a separate operation.

## Observed code and test behavior

- `action_server/src/actions/server/_actions_process_pool.py` sets `use_tcp = True` for `ProcessHandle`; the normal child is launched with `--tcp`. The stdio branch is currently unreachable. `_connect_to_socket()` resets its timeout to `None`; the accepted socket is used to create `makefile("rb")` and `makefile("wb")` streams, but the raw socket is not retained by the handle.
- `action_server/src/actions/server/_preload_actions/preload_actions_streams.py` implements `JsonRpcStreamWriter.write()` and `.close()` under an ordinary blocking lock. `write()` performs buffered writes and flush; `.close()` calls the buffered stream's `.close()`. Neither operation has a deadline. Both streams share the same socket; Python socket timeout changes can also affect the reader.
- `ProcessHandle.kill()` in `_actions_process_pool.py` uses `_kill_called` as a liveness shortcut and sets it before cleanup completes. `RccProcessHandle.kill()` in `_rcc_runtime_adapter.py` kills the process tree and then calls unbounded `Popen.wait()`. `_common/process.py:kill_process_and_subprocesses()` sends terminate, waits for its soft phase, and sends kill to survivors, but does not wait for those survivors afterward.
- Worker cleanup is invoked under the pool lock in reload, disposal, and completed-action finalization. The action semaphore is released afterward in a `finally`. Active scheduler cancellation calls `ProcessHandle.kill()` while `run_action()` is still active. Completed-action finalization happens after the return code and result/output writes have been collected.
- Existing tests cover active force-kill/replacement (`test_actions_process_pool_process_crash`), wrapper wait after kill (`test_process_handle_kill_waits_for_wrapper`), and exactly-once semaphore release after successful fake reaping even when warmup fails. They do not cover deadline-bounded send, timeout retries, or an unreaped/quarantined worker.
- The opt-in RCC vertical test currently observes `status="failed"`, `exitCode=-1`, `reason="child exited non-zero"` after a successful Action whose persistent wrapper is force-killed. `read_receipt()` validates artifact digest, verification, and lease identity; it does not classify status. Keep failed receipt outcomes as failures. A clean-exit receipt outcome has not been established in this read-only review.

## Proposed boundary (not implemented)

Add a synchronous `ProcessHandle.retire(deadline)` path for idle/completed, nonreusable workers. It should send JSON-RPC `method: "exit"`, allow an in-flight synchronous Action to finish before becoming eligible, wait for the RCC wrapper, and force-stop/reap on graceful timeout. Keep active cancellation on the immediate force-kill path; do not route it through graceful retirement.

Use one absolute monotonic deadline for writer-lock admission, frame send/flush, wrapper wait, forced tree termination, and reap. Do not create a detached writer thread or rely on generic unbounded `BufferedWriter.close()` for timeout cleanup. Track monotone handle state so a partial/failed exit send is never retried as a second frame, an already-dead child still gets wrapper wait/reap, and a timeout can be retried without marking the handle dead before it is reaped. Only a fully reaped wrapper completes retirement; examine its receipt without changing its status or exit code.

Pool ownership should detach retirement candidates under the pool lock, then perform blocking retirement outside that lock. A timed-out handle must remain nonreusable and visible as incomplete; it must not be silently treated as lease-released. The precise quarantine/accounting and semaphore behavior needs resolution before implementation.

## Unresolved decisions

- **Bounded send:** `socket.settimeout()` is the apparent small primitive, but the reader shares the socket and can also time out. Confirm a portable send bound and expected reader cleanup behavior. The raw socket must first be retained; do not assume buffered `close()` supplies the bound.
- **Deadline policy:** Select the timeout and reserve time for force-stop/reap so a stuck write cannot consume the whole deadline before termination is attempted.
- **Incomplete reap and capacity:** A strict deadline cannot guarantee reap of an unkillable process. Define how a pending handle stays accounted, how/when later reaping is retried, and whether/when Action concurrency capacity may be released. Do not add broad pool/quarantine state until this contract is decided.
- **Receipt evidence:** Future pinned RCC acceptance must inspect the exact receipt produced by explicit worker exit. Preserve any failed/nonzero receipt as failure; do not infer wrapper success from a successful Action.

## Suggested regression coverage

1. Successful idle retirement sends exactly one exit only after Action outputs/result are complete, then reaps the worker/wrapper.
2. A held writer lock and a saturated socket each return within the deadline without creating a detached writer thread; failed/partial send triggers force-stop.
3. A single deadline is consumed across send, graceful wait, force-stop, and reap; reserve enough time for forced termination.
4. An already-exited worker skips the exit frame but still waits/reaps the wrapper; repeated retirement after timeout does not resend the frame and only becomes complete after reap.
5. Pending retirement is nonreusable and remains accounted; pool lock is available during cleanup; semaphore/capacity transitions occur exactly once, including warmup failure.
6. Active cancellation still force-kills without sending exit; failed RCC receipt fixtures remain failed.

## Documentation receipt

- **Canonical file proposed:** `docs/skills/repository-operations.md` after implementation evidence exists; no future-behavior paragraph was added here.
- **Durable learning captured:** Current TCP/shared-reader/buffered-write ownership, cleanup/wait limitations, existing receipt outcome, and the unresolved design boundary.
- **Evidence:** Source and tests at `ea08faf39e107113ae50a529770ce1ca1a422d05`; full #134 contract.
- **Stale or ambiguous guidance removed:** None; this artifact records current facts and deferred choices only.
- **Remaining uncertainty:** Portable deadline-bounded send, deadline value/force reserve, and pending-retirement capacity/retry policy.
