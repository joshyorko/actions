# #214 standalone exposure lifecycle: next-slice design

Date: 2026-10-09  
Repository baseline: `feature/tunnel-edge-verification-20261009` at `82f526efc741781b0a08649cd1ecf0f8d2579f0c`  
Scope: read-only architecture proposal; no provider, external endpoint, secret, or public listener was used. The source worktree remained unchanged.

## Decision

The smallest coherent next slice is a single Runtime-owned exposure coordinator that both `action-server start --expose` and the standalone `action-server expose start/status/stop` CLI use. The coordinator must own the provider manager, Runtime identity and API-key context, exact temporary MCP SDK host/origin admission, edge-readiness probe, sanitized lifecycle state, and cleanup. A second CLI process cannot independently provide first-class readiness because the actual MCP SDK settings and key-bearing Runtime are owned by the live server process.

This is a proposal, not implemented behavior. PR #236's legacy authenticated edge probe does not complete the first-class persisted lifecycle in #214.

## Contract context

The retained #214 acceptance contract says the explicit CLI lifecycle and `start --expose` compatibility path must delegate to one implementation. It also requires readiness to prove expected Runtime identity and auth policy plus canonical `/mcp` initialization without an Action call; failed exposure must leave local Runtime usable; status must be inspectable; and stop/reconcile may only clean up resources the lifecycle owns. The governance record contains no retained comments for #214 (`comments_record.structuredContent.comments` is empty).

## Verified current behavior

- The standalone parser accepts `expose start --provider ... --port ...`; it has no API-key or data-directory argument. `action_server/src/actions/server/_cli_impl.py` lines 279–310.
- `start --expose` resolves an explicit API key in memory or loads the generated key from the selected data directory, then passes it into `start_server`. `action_server/src/actions/server/_cli_impl.py` lines 1105–1117. A custom `--api-key` therefore exists in the server process but is not implicitly available to the standalone `expose` process; persisting it to bridge processes would expand secret storage unnecessarily.
- Standalone lifecycle creates its own `TunnelManager`, starts the provider and persists sanitized process/provider/endpoint metadata with status `starting`. It has no `Runtime` object, expected `mtime_uuid`, API key, or reference to the live MCP transport-security settings. `action_server/src/actions/server/_community_expose_lifecycle.py` lines 201–263.
- Standalone `_receipt()` marks an absent/replaced owned process stale, but maps a surviving `starting` or `ready` receipt back to `starting` with `edge-readiness-not-verified`. A provider PID alone cannot establish edge readiness. `action_server/src/actions/server/_community_expose_lifecycle.py` lines 166–188.
- Standalone foreground wait/cleanup and separate-process stop operate on the lifecycle process's provider ownership. They are not the Runtime's manager or lifecycle callbacks. `action_server/src/actions/server/_community_expose_lifecycle.py` lines 265–331.
- The legacy server path has the in-memory app and key. With a key, it admits the validated exact tunnel host/origin into the helper, registers release on the owned manager, probes, and stops the owned provider on probe failure. `action_server/src/actions/server/_server.py` lines 179–245.
- That probe checks `/config` auth and matching `mtime_uuid`, requires unauthenticated `/mcp` initialize to return 401/403, and then uses the MCP client SDK for authenticated initialize. It uses verified TLS, disables redirects, applies one eight-second deadline, and makes no Action call. `action_server/src/actions/server/_server.py` lines 248–352.
- MCP DNS-rebinding protection remains enabled. The helper starts with loopback-only host/origin allowances and adds/removes exact HTTPS host/origin entries with reference-counted ownership. The live streamable HTTP app receives that same settings object. `action_server/src/actions/server/mcp/setup_mcp_server_v2.py` lines 68–179; `action_server/src/actions/server/_api_action_routes.py` lines 159–165. A standalone process changing its own settings cannot authorize the settings object used by the live app.
- Existing repository guidance already records that the authenticated legacy path does not mark the separate persisted lifecycle ready and that local ASGI proof is distinct from real-provider/TLS and native CI gates. `docs/skills/repository-operations.md` lines 863–885.

## Readiness blockers and smallest seam

| Concern | Verified blocker | Required coordinator capability |
|---|---|---|
| API key | Only the Runtime start path necessarily has the effective key; custom key is memory-only. | Receive a borrowed in-memory key from Runtime. If a separate CLI must initiate lifecycle, define a narrow authenticated local control handoff; never put the key in argv, environment, URL, logs, receipt, or new persistence. |
| Runtime identity/config | Standalone has no authoritative expected Runtime `mtime_uuid`; public `/config` by itself cannot prove it reached the selected local Runtime. | Snapshot the intended Runtime identity and configuration from the live Runtime, validate public `/config` against it, and fail on identity/reload mismatch without unbounded retry. |
| MCP auth/protocol | `auth_enabled` does not prove enforcement; standalone has no key to test valid initialization. | Require missing-auth initialize rejection (401/403) and valid Bearer SDK `initialize` with a validated MCP response; no tools/action call. Keep HTTPS, TLS verification, no redirects, same expected origin, URL validation before authenticated requests, and one total monotonic deadline. |
| DNS-rebinding host scope | Separate CLI cannot mutate the actual settings instance used by the app. Disabling the guard or wildcard allowances is not acceptable. | Runtime-owned capability adds only the validated exact host and origin to the shared live settings while its provider is probing/active; scoped release preserves prior entries and handles overlap/idempotence. |
| Provider/process ownership | Standalone CLI and server lifespan each create an independent `TunnelManager`; shared provider implementation is not shared lifecycle ownership. | One coordinator owns exactly one manager and its cleanup callbacks. `stop`, failed probe, and Runtime shutdown stop only that owned provider and revoke the scoped host admission. |
| Persisted status | Standalone receipt deliberately stays `starting`; legacy path verifies the edge but does not write the persisted lifecycle receipt. | Coordinator is authoritative for `starting -> ready` only after every readiness check; failed verification yields failed/degraded state, while the local Runtime continues serving. Persist only sanitized metadata. Reconcile stale owner identity and never infer ready from PID liveness. |

## Proposed narrow architecture

1. Introduce an internal Runtime-owned coordinator API (name provisional, e.g. `ExposureCoordinator`) constructed with the live app identity/config accessor, effective key provider, the exact MCP transport-security helper, and one provider manager. It is a lifecycle seam, not a generalized network/provider framework.
2. Route legacy `start --expose` through this coordinator, preserving its current compatibility behavior. It passes the already available in-memory key and Runtime context; the coordinator performs start, validation, probe, status recording, and cleanup.
3. Make standalone lifecycle commands clients of the Runtime-owned coordinator through a narrow local-only control channel. They must not create a competing `TunnelManager`. A default key loaded from the same data directory is not sufficient for custom in-memory keys; either the server must authorize the local command without disclosing the key or a reviewed explicit secret handoff (for example protected inherited descriptor/peer-credentialed IPC) must be chosen. Do not persist the key to make the CLI work. The channel is an architectural decision gate: a local HTTP route is acceptable only if it is demonstrably loopback-only and does not expand public app routing; otherwise use bounded local IPC appropriate to supported platforms.
4. Keep coordinator state under the existing sanitized lifecycle storage contract. Store no API key or bearer material. Status while Runtime lives comes from coordinator state; after Runtime exit, reconcile by owned process identity and report stale/stopped without claiming readiness. Stop is idempotent and scoped to coordinator-owned provider resources.
5. Preserve provider security distinctions and passive discovery. This slice does not claim configured Cloudflare token provisioning, quick-tunnel reliability, Bore support (currently rejected for HTTPS Runtime exposure), standalone service management, or native/live provider coverage.

## State and failure behavior to implement

`STOPPED -> STARTING -> READY` is allowed only after provider ownership is established, the URL passes strict HTTPS/origin validation, local and public Runtime identity/config agree, missing-auth initialize is rejected, and authenticated SDK initialize validates. Any failure after provider start must release the exact host/origin scope and stop the exact owned provider with bounded cancellation-safe cleanup; report failure/degraded exposure while leaving the local Runtime serving. Runtime shutdown always releases the scope and stops its owned provider. Reload/identity mismatch fails closed rather than retrying indefinitely.

## Test topology for this next slice

All tests should use synthetic keys and an in-process ASGI app plus a fake owned provider/transport; no external tunnel, account, credential, public listener, or endpoint.

- Legacy `start --expose` and standalone `expose start` both invoke the same coordinator and one manager instance; assert a second manager is not created.
- `/config` identity match succeeds; wrong Runtime UUID, disabled auth, or a changed UUID fails readiness.
- Missing-auth MCP initialize receives 401/403; valid synthetic Bearer initialize gets a valid MCP protocol response; no Action/tools/call is invoked.
- Before probing, reject malformed/non-HTTPS/credential-bearing/query/fragment URLs without sending an authenticated request; transport verifies TLS, does not follow redirects, preserves expected origin, and all calls consume one deadline.
- During probe/active ownership, exact tunnel host and origin are present on the same settings object used by the live SDK app; DNS-rebinding protection remains enabled. With valid synthetic auth, unrelated Host still receives 421; no-auth expected-host request still receives 401/403. After probe failure, stop, or Runtime shutdown, exact entries are removed and expected host is denied again. Pre-existing entries remain; overlapping acquisitions/ref-counted releases are idempotent.
- Failure at each start/probe/state-write/stop boundary leaves local Runtime serving, releases only owned resources, and cannot overwrite a newer owner receipt. Stale/replaced PID is not stopped as an unrelated process.
- Status reports `starting` during probe, `ready` only after successful completion, and failed/degraded with sanitized reason after rejection. Stop/status remain idempotent across process exit/reconcile.

## Canonical documentation proposal (not applied)

Target: `docs/skills/repository-operations.md`, adjacent to the existing authenticated legacy exposure paragraph (currently lines 863–885).

Exact proposed paragraph:

> `action-server expose start` remains a separate foreground lifecycle: it creates its own `TunnelManager`, records the provider PID and creation time as `starting`, and `_receipt()` continues to report `starting` with `edge-readiness-not-verified` while that process exists. This command has no in-memory Runtime API key or expected `mtime_uuid`, and it cannot grant the live MCP app's transport-security settings. Do not infer public-edge identity/auth readiness or first-class lifecycle completion from a live provider PID. A Runtime-owned coordinator and local control path shared with `start --expose` are proposed follow-up work, not current behavior. The coordinator design must keep the MCP SDK DNS-rebinding guard enabled and scope exact tunnel host/origin admission on the same settings instance used by the live app.

This delta records the verified process/identity/settings ownership gap and keeps planned architecture explicitly separate from current behavior. Existing guidance already covers the legacy probe and separate standalone lifecycle being unready; this paragraph adds the missing concrete reason and avoids a false #214 completion claim.

## Limits

This design does not establish whole-issue #214 acceptance, real provider/TLS behavior, native-platform behavior, an external tunnel's security guarantees, a chosen local control-channel implementation, or first-class persisted readiness. Those remain later implementation/verification gates. PR #236 should be described only as the narrower legacy authenticated edge check plus its verified checkpoint.
