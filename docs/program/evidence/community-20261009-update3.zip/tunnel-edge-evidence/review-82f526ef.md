# Read-only review: PR236 public tunnel verification

Reviewed `554630899c6eab23b922ba6558347e7f2c439c00..82f526efc741781b0a08649cd1ecf0f8d2579f0c` in the clean `tunnel-edge` worktree. Scope was the legacy `action-server start --expose` authenticated startup path, identity/authentication probe, MCP host/origin scope and teardown. No live provider traffic or tests were run.

## Findings

No actionable defect found in the reviewed diff.

Evidence checked:

- `_start_community_expose_impl` refuses plain-HTTP Bore, registers exact-origin cleanup before probe, stops the manager and releases the origin on any probe exception/cancellation, and logs the public URL only after verification (`action_server/src/actions/server/_server.py:179-245`).
- `_verify_public_tunnel` accepts only an HTTPS origin URL, enables TLS verification, disables redirects on both clients, binds the `/config` response to the current Runtime `mtime_uuid`, requires auth enabled, requires unauthenticated MCP initialize to return 401/403, then performs SDK `ClientSession.initialize()` with the configured bearer key and rechecks the identity. The whole sequence has an absolute eight-second asyncio deadline (`_server.py:248-351`).
- The production MCP route receives the same mutable `TransportSecuritySettings` object as `McpServerSetupHelper`; tunnel host/origin entries are exact, HTTPS-only, reference counted, idempotently released, and pre-existing loopback/host entries are preserved (`_api_action_routes.py:159-165`, `mcp/setup_mcp_server_v2.py:65-178`). The compatibility import path used by `_api_action_routes` reexports the v2 helper.
- Startup failure coverage asserts the manager is stopped, the temporary host allowance is removed, the public URL is not logged, and the API key does not appear in logs. The ASGI MCP scope test checks DNS-rebinding protection, unrelated-host rejection, missing authorization rejection and successful SDK initialization. These are local synthetic tests only.
- `git diff --check` passed for the reviewed commit range.

## Documentation improvement

- Canonical file changed or proposed: no additional change proposed; `docs/skills/repository-operations.md:874-886` already accurately documents the public `/config` identity check, unauthenticated and authenticated MCP initialize probes, same-settings-object requirement, temporary exact scope, cleanup behavior, and the gap between local ASGI evidence and real provider/TLS/native acceptance.
- Durable learning captured: existing canonical guidance matches the code and states the evidence boundary for the legacy `--expose` path.
- Evidence: source, scoped tests above, and the diff check; no tests were run by this reviewer.
- Stale or ambiguous guidance removed: none; no contradiction found in the existing section.
- Remaining uncertainty: live provider/TLS forwarding, native CI, and standalone persisted `action-server expose start/status` remain outside this review and unverified.
