# PR231 native Work Items acceptance review

## Scope and evidence

Read-only source/receipt review at checkout `/workspace/work/community-resume/workitems`, HEAD `5d295a9272097af8728b40beb774a947a5df9ce7`, branch `resume/workitems-review-20261009`, clean during inspection. Compared preserved harness baseline `d78534f1` through finalization change `703837e5` and current docs/source. Inspected `action_server/scripts/dakota_workitems_native_acceptance.py`, the consumer lifecycle test and its harness tests, canonical `docs/skills/work-items.md`, and retained receipts `action_server/tests/evidence/dakota_workitems_native_acceptance_resume_20261009.json` and `...integrity_20261009.json`. No tests/builds/services were rerun; no processes were launched. Existing receipt records a Linux x86_64 run at harness SHA `703837e5...`, with 2 packaged-runtime cases passing in 10.91 seconds, artifacts not rebuilt, and separate integrity checks. It does not establish current-source artifact builds or non-Linux results.

## Admission finding: stale PASS can survive abrupt interruption

**Confirmed blocker, now fixed in the working tree:** the prior runner created an in-memory `IN_PROGRESS` object at line 271 but only wrote it in `finally` at line 351. A prior PASS therefore survived while artifacts were hashed and pytest ran. Default SIGTERM/process termination could exit without `finally`, leaving that old PASS at the receipt path. Existing `KeyboardInterrupt` coverage reached `finally` but did not model abrupt termination. Post-pytest artifact hash changes were already correctly rejected and tested.

Implemented bounded fix: after CLI parsing/validation and before artifact checks or pytest, the runner removes an earlier receipt and atomically writes a fresh schema-2 `IN_PROGRESS` receipt with a new `attempt_id`. If an abrupt stop occurs during that write, the old PASS has already been removed; after publication, the interrupted state is IN_PROGRESS. A genuine subprocess regression pre-seeds a PASS, blocks inside a pytest shim, checks the new attempt receipt, terminates only its owned runner process, and verifies the retained receipt remains IN_PROGRESS. The previous runner was checked against this test first: it failed with the old status still PASS. The updated focused admission file passes all 15 tests.

## Other admission checks

- Hash path: the runner hashes both executable files and the task-local Core wheel before pytest, hashes them again after pytest, and rejects changes before `finalize_success`. Failure receipts drop action/readback claims and mark cases `NOT_VERIFIED`. Existing integrity test covers a changed executable and a `KeyboardInterrupt` during final hashing; it does not cover the stale prior-receipt issue above.
- Proof path: proofs are created in a new invocation-specific temporary directory under the receipt parent; the suite requires exactly the two known case reports, each passing setup/call/teardown, and exact proof filenames/content. Each proof declares its runtime kind and measured executable/Core wheel hashes, and the parent runner validates them against its measurements. Atomic proof writes prevent partial JSON. This is a sound admission boundary for the tested artifact paths.
- Source/build identity: receipt fields accurately label `source_sha_claim` and `build_version_claim` as caller supplied and unverified against a build manifest. Executable hashes identify the exact files observed by this runner, not the source commit from which those files were built. The retained receipt is honest about no artifact rebuild. Do not treat it as current-source build evidence.
- Consumer scenarios: success verifies reserve, done state, linked output, output queue and payload; failure verifies API 500 plus persisted FAILED state and error code/message; recovery directly seeds an old IN_PROGRESS row in the harness DB, then the packaged consumer calls `recover_orphaned_work_items`, retries, and completes it. The code and receipt explicitly say this is a stale-row fixture, not a simulated process crash. Restart uses the same selected executable and same datadir and rechecks states/stats/output parent links.
- Process cleanup: the primary server process is stopped before restart; restarted server is stopped in `finally`; the fixture teardown stops the original process again safely. The harness’s temporary proof directory is context-managed on normal Python exit. Abrupt termination can leave that temporary directory behind, but that is separate from receipt correctness and does not retain PASS once the required early receipt invalidation is added.
- Full #208 boundary: this PR’s native gate proves only these two Linux packaged-worker cases under its task-local RCC/Core inputs. It does not close the separate 24-failure broad diagnostic, establish current source-build provenance, cover all native platforms, or replace the credential-free browser/persistence gates. Keep all those claims bounded.

## Canonical documentation change

Target: `docs/skills/work-items.md`, the Dakota packaged-worker gate paragraph around lines 132–151. The existing sentence “Failed or interrupted final checks invalidate every case and remove success readbacks from the receipt” overstates the current runner for an abrupt process termination when a previous PASS file already exists.

The canonical guide was updated to state the implemented receipt lifecycle:

> Each attempt removes any prior receipt, then atomically writes a fresh `IN_PROGRESS` receipt and attempt ID before artifact checks or pytest. Ordinary failures write `FAIL` and mark cases `NOT_VERIFIED`; abrupt termination can leave `IN_PROGRESS`, which is not a passing result. Source SHA and build version arguments are caller claims, not verified build provenance.

Evidence: the runner invalidates/writes the receipt before artifact validation; `test_abrupt_process_termination_invalidates_previous_pass` demonstrates old source failure and current source success. Final-hash/interruption simulations and the positive controls remain in `test_dakota_workitems_native_acceptance_harness.py`. Ruff and mypy passed through RCC `Lint` and `Typecheck`. The retained historical integrity receipt has harness SHA `703837e5...`, two passing Linux cases and no artifact rebuild; it is not evidence from the current source commit.

## Configured package gate

The exact RCC Action Server portable command was first run without the assigned
environment activation, then rerun in the task-owned environment. The first
attempt is diagnostic only: it used `/home/agent/.robocorp` and selected
`/usr/bin/python3.13`, rather than the prepared interpreter. Its failure was
traced to missing Debian `python3.13-venv`/`ensurepip`; that failed attempt is
not the configured package-gate result. No package was installed.

The successful package-gate command sourced `/workspace/actions-cloud/activate.sh`
and ran:

```text
rcc task script -r developer/toolkit.yaml -- python -c 'import toolkit; toolkit.poetry("action_server", "run", "invoke", "test-not-integration")'
```

The activated run passed: 588 passed, 10 skipped, 4 warnings in 109.75 seconds. In this run, `_runtime_python()` selected the prepared interpreter supplied by `activate.sh`, and the clean-wheel contract test passed. The earlier unactivated diagnostic remains documented as an environment misconfiguration, not a package failure. The broader developer `Test` run also hit the same host-interpreter issue before activation and is not the bounded package gate. Focused admission tests passed 15/15; RCC Lint and RCC Typecheck passed. A process reported by RCC after the earlier broader run was inspected and is a defunct zombie under PID 1; no live process from this lane remains.

Documentation improvement:
- Canonical file changed or proposed: `docs/skills/work-items.md` changed in this working tree; exact delta described above.
- Durable learning captured: A preexisting PASS is removed before writing a unique IN_PROGRESS attempt, so abrupt termination cannot preserve stale PASS evidence after attempt publication begins.
- Evidence: Red/green subprocess regression, focused 15-case result, RCC Lint/Typecheck passes, and source inspection.
- Stale or ambiguous guidance removed: Replaced an overbroad claim that interruptions always write FAIL with the accurate distinction that abrupt termination can leave IN_PROGRESS.
- Remaining uncertainty: Historical native receipt is for 703837e5 artifacts and does not prove current-source builds.
