Cloudflare tunnel discovery keeps stdout and stderr fragments separate, drains output after URL discovery, and bounds cancellation when descendants inherit pipe writers. Reader cleanup uses nonblocking reads, joins before stream closure, and runs off the event loop while preserving cancellation.

This repairs the two-file patch preserved as unverified in the October 8 evidence archive. The archive remains byte-identical (SHA-256 `3b3ebf05a5a276eaca755d9e48bee23618b5828f1d0ab9603a31dd7f9ae3eb06`). The focused tunnel tests are in the credential-free Linux, Windows, and macOS workflow.

Current head `2d4933a77d300614b7de2e6dc328d77f7947283d` validation: RCC v18.19.3 Doctor, Bootstrap, and ToolkitTest passed (33 tests); focused tunnel tests passed (41); configured Action Server portable tests passed (607, 10 skipped); package lint passed; typecheck passed (284 source files). Markdown lint was unavailable in the configured toolchain.

Historical native run [37946053759](https://github.com/joshyorko/actions/actions/runs/37946053759) used the prior head `cff801836e8adae160aef7db7bdc5189c8d2b403`: the focused tunnel tests passed on all three platforms, but the complete Windows job failed its separate native process-ownership check. `test_job_drains_descendant_handle_before_owned_process_returns` observed `WaitForSingleObject(handle, 0) == 258` (WAIT_TIMEOUT), expected 0. Linux and macOS whole native jobs passed. This branch now includes the integration branch's Windows ownership repair, but a current-head native rerun remains unverified.

Live provider/public-edge identity, authentication, and SSH identity acceptance remain unresolved. This draft records bounded tunnel integration work and does not establish whole #214 completion or release readiness.

Canonical operational guidance is in `docs/skills/repository-operations.md`, including reader queue/drain behavior, cancellation cleanup, and the separation between focused tests and native/provider acceptance.
