# Independent review: Robot private staging successor

Reviewed immutable commit `0721ebc0ac473e8ff32f418131476976a1169b07` against base `af4f706edd3d34e50bd50c8f42ca28530ff6b669`. Review was read-only; no tests or builds were run by this reviewer. Writer-reported validation: focused 56 and full Action Server gate 589 passed, 10 skipped (not independently reproduced here).

## Findings

No blocker found in the bounded staging change. The implementation creates a separate `0700` container and precreated package child before `copytree`; source directory metadata can change the package child but does not widen the container on POSIX. It records `(st_dev, st_ino)` identities, only recursively removes the package child when the recorded identity still matches, and removes the container with `rmdir`, which leaves it intact when a foreign child remains. Tests cover private mode during file copies and after copytree, partial-copy cleanup, package-child replacement before cleanup, and container replacement after successful native publication.

No-replace behavior remains intact: initial final-name collisions select a suffix; a final destination appearing during copy or at native rename is preserved and retried. An initial staging-container name collision is preserved and fails closed rather than being cleaned up as owned staging. Unsupported/native rename failures remain fail closed. This review does not claim that path-based identity-check-then-delete is race-free if an actor replaces a path between the check and removal; the guide explicitly retains that cleanup race gap.

The guide accurately limits the result: Windows ACL isolation is unverified; root/source capability identity and replacement races are out of scope; POSIX private-parent mode evidence does not prove a complete sandbox. No broad root/source race claim was introduced.

## Documentation improvement

- **Canonical file changed or proposed:** `docs/skills/repository-operations.md` (changed in the reviewed commit).
- **Durable learning captured:** `copytree` applies source-directory metadata to an existing destination; a private parent keeps the copied payload mode from widening the staging boundary on POSIX. Cleanup ownership is identity-checked for both container and package child, with `rmdir` preserving later occupants.
- **Evidence:** Production code and regression coverage in commit `0721ebc0`; writer-reported focused 56 and full gate 589 passed / 10 skipped. Tests were not rerun by this read-only reviewer.
- **Stale or ambiguous guidance removed:** Replaced the previous allocation-flag-only staging description and removed any implication that ownership flags establish identity after replacement.
- **Remaining uncertainty:** Windows ACL behavior is unverified. Pathname identity checks followed by recursive deletion still have a check/remove race; root/source capability identity remains unproven. The staging-name collision path preserves the foreign entry but fails closed instead of choosing another staging name.
