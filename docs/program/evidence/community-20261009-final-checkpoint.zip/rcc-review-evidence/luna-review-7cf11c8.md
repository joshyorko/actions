# Independent review: Dakota RCC acceptance candidate `7cf11c8`

Review scope: `d8406db23504320a1e78a7624f4f3d17a4f5b83b..7cf11c8bbad67a5dbfa9387ce82d8ca35f5c8c4e`, limited to `action_server/scripts/verify_dakota_rcc_acceptance.py` and `action_server/tests/action_server_tests/test_dakota_rcc_acceptance.py`. Read-only; no acceptance run, build, or test invocation was performed.

## Findings for integration

1. **Unconditional adopted-child reap is missing on the successful path.** `_supervisor_main.live_children()` excludes zombies. If the owner command exits successfully after spawning a detached child which exits before the snapshot, `descendants` is empty, so the `if timed_out or descendants` branch skips `waitpid`. The adopted zombie is not reaped before the supervisor returns success. Reap adopted children on all completion paths and verify `waitpid(-1, WNOHANG)` reaches `ChildProcessError`/`ECHILD`; add a successful-owner fast-exit detached-child regression that distinguishes exited from reaped.
2. **Unexpected descendants can be silently cleaned while preserving success.** On normal owner exit, any live descendants are terminated, but the result retains `timed_out=False` and the owner's original zero return code. This lets the caller report success after the supervisor repaired an ownership leak. Define this disposition explicitly and test it; if no-background-descendant is the contract, make cleanup intervention fail the command/acceptance.
3. **Supervisor inspection failure is fail-open.** `live_children()` converts any `psutil.Error` into `[]`, which can be mistaken for a complete empty process tree. Ownership inspection failure must reject cleanup. Also guard the post-`Popen` supervisor body so internal exceptions trigger bounded termination and reaping before the supervisor exits.

The pushed regression `test_early_owner_exit_cleans_detached_inherited_pipe_writer` exercises a live detached, SIGTERM-ignoring child and proves disappearance before returning from the outer test. Its nested `invoke` script accepts either a `TimeoutExpired` or successful `CompletedProcess`, so it does not assert whether the supervisor reports cleanup intervention as success. The new terminal receipt tests do cover missing/false/running status, missing code, bool, string, and nonzero code; the classifier accepts only `status == "completed"` and `type(exitCode) is int and exitCode == 0`. The Runtime adapter's `read_receipt` itself checks identity, verification and nonempty lease but not terminal success, so this classifier is the additional terminal contract.

The non-Linux entrypoint now returns status 2 before `_run`; the check is only a mocked-platform unit assertion, not platform acceptance evidence. The work is Linux-only as currently documented by the failure message.

## Documentation proposal

Canonical file: `docs/skills/repository-operations.md`, in the existing RCC/Runtime acceptance guidance.

Proposed durable delta, after resolving the findings above: “The Dakota candidate-wheel acceptance CLI is verified only on Linux and fails closed before acceptance side effects elsewhere. Its Linux command runner uses a dedicated `PR_SET_CHILD_SUBREAPER` supervisor and requires terminal RCC receipt status `completed` with an actual JSON integer `exitCode` of zero; the Runtime adapter's generic receipt reader alone does not establish terminal success. Cleanup evidence must distinguish a stopped process from a reaped child and must reject ownership-inspection failures.”

Evidence: pushed implementation and focused assertions at `7cf11c8bbad67a5dbfa9387ce82d8ca35f5c8c4e`; no tests or live run were executed in this review lane. The durable claim about reaping must wait until unconditional child reaping and failure-path behavior are fixed and covered.

## Required receipt

Documentation improvement:
- Canonical file changed or proposed: `docs/skills/repository-operations.md` (proposed exact delta above).
- Durable learning captured: Linux-only fail-closed boundary; subreaper and exact terminal RCC completion contract; distinction between process stop and child reap.
- Evidence: code and unit tests in the reviewed pushed delta; no tests were run by this reviewer.
- Stale or ambiguous guidance removed: none proposed; current docs make no specific claim about this Dakota harness.
- Remaining uncertainty: whether pending fixes make reaping unconditional, cleanup intervention fail closed, and psutil inspection/internal supervisor failures cleanup-safe; candidate live receipt remains separate acceptance evidence.

## Successor review: `79b95e85`

Read-only delta reviewed: `7cf11c8bbad67a5dbfa9387ce82d8ca35f5c8c4e..79b95e85c6fc2e0dc335e1b6ca93f2c59a5091bd`. Static review found the three findings above addressed in source and regression intent: adopted-child draining now runs on normal and cleanup paths until `ECHILD`; unexpected live descendants raise and demote an existing receipt; psutil enumeration and status errors fail closed, with an exception cleanup path using Linux `/proc` enumeration and termination. The added fast-exit child test asserts the reaped disposition, positive reap count and child PID disappearance. The exact `candidate-wheel-7cf11c8b.json` preserves the separate historical live probe result as overall `FAIL` with `wrapper_exit=FAIL`, `status=failed`, `exitCode=-1`; the older e339 receipt remains untouched.

No tests or live acceptance were run by this reviewer. I found no additional static blocker in this successor. Before claiming the fixes verified, confirm the worker's focused test results and preserve any new live probe receipt unchanged. The documentation delta proposed above is now supported by source and focused assertions, with Linux-only claims still limited to the actual Linux test evidence; do not infer cross-platform cleanup acceptance.

Updated documentation improvement receipt:
- Canonical file changed or proposed: `docs/skills/repository-operations.md`; exact Linux-only subreaper and terminal-receipt proposal remains for integration.
- Durable learning captured: receipt terminal success is distinct from artifact verification; Linux descendant success requires reaping adopted children, and live descendants cleaned after nominal command exit mean cleanup failure.
- Evidence: source/tests in `79b95e85c6fc2e0dc335e1b6ca93f2c59a5091bd`; focused assertions were inspected but not executed by this reviewer; failed live receipt is checked in as a separate artifact.
- Stale or ambiguous guidance removed: none in this read-only lane.
- Remaining uncertainty: actual focused test output and any fresh live candidate result; native non-Linux behavior remains deliberately unclaimed.
